public class MilitaryCard extends Card {
    private int militaryPoints;
    
	public MilitaryCard(int age, String types, String names, String upgrades, String cost, int mp) {
		super(age, types, names, upgrades, cost);
		setMilitary(mp);
	}
	public void setMilitary(int mp)	{
		militaryPoints = mp;
	}
	public int getCardWorth() {
		return militaryPoints;
	}
	public void print()
	{
		super.print();
		System.out.print(", MILITARY POINTS: " + militaryPoints);
	}
}
