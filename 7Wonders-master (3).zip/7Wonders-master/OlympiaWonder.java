
import java.util.TreeMap;

public class OlympiaWonder extends Wonder{
    private Card freeBuild;
	public OlympiaWonder(int lvl, String mat, String named, String[] level1, String[] level2, String[] level3) {
		super(lvl, mat, named, level1, level2, level3);
		// TODO Auto-generated constructor stub
	}
	public Card getFreeBuild() {
		return freeBuild;
	}
	public void setFreeBuild(Card freeBuild) {
		this.freeBuild = freeBuild;
	}
	

}