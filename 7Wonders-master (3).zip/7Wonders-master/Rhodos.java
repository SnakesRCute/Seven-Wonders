import java.util.TreeMap;

public class Rhodos extends Wonder{
	private int extraMilitary;
	public Rhodos(int lvl, String mat, String named, String bonuses, TreeMap<String, Integer> upgrade, int mil) {
		super(lvl, mat, named, bonuses, upgrade);
		setExtraMilitary(mil);
	}
	public int getExtraMilitary() {
		return extraMilitary;
	}
	public void setExtraMilitary(int extraMilitary) {
		this.extraMilitary = extraMilitary;
	}
}
