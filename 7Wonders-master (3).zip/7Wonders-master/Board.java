import java.util.TreeMap;
import java.util.TreeSet;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class Board {

	private Wonder[] wonders;
	private TreeMap<Integer, ArrayList<Card>> deck;
	private ArrayList<Card> discard, currentAge;
	private Deck allCards;
	private Player[] allPlayers;
	private int age, turn;

	public Board() throws IOException {
		createWonder();
		deck = new TreeMap<>();
		allCards = new Deck();
		Player one = new Player("Player One");
		Player two = new Player("Player Two");
		Player three = new Player("Player Three");
		allPlayers = new Player[3];
		allPlayers[0] = one;
		allPlayers[1] = two;
		allPlayers[2] = three;
		discard = new ArrayList<>();
		for (int i = 0; i < allPlayers.length; i++) {
			deck.put(i, new ArrayList<Card>());
		}
		age = 1;
		turn = 0;
	}

	public TreeMap<Integer, ArrayList<Card>> getDeck() {
		return deck;
	}

	public Player[] getPlayers() {
		return allPlayers;
	}

	public int getTurn() {
		return turn;
	}

	public int checkHandSize() {
		return deck.get(allPlayers[0]).size();
	}

	public void nextAge() {
		age++;
	}

	public void nextPlayer() {
		if (age != 2)
			turn = (turn + 1) % 3;
		else {
			if (turn == 0)
				turn = 2;
			else
				turn--;
		}
	}

	public void nextTurn() {
		ArrayList<Card> temp = deck.get(turn);
		for (int i = 0; i < 3; i++) {
			nextPlayer();
			ArrayList<Card> temp2 = deck.get(turn);
			deck.put(turn, temp);
			temp = temp2;
		}
		// idk if it works lol
	}

	public void createDeck() {
		ArrayList<Card> temp = new ArrayList<Card>();
		if (age == 1)
			temp = allCards.getAge1();
		else if (age == 2)
			temp = allCards.getAge2();
		else if (age == 3)
			temp = allCards.getAge3();
		else
			System.out.println("Player deck failed to create");
		currentAge = temp;
	}

	public void createWonder() throws IOException {
		String[] fileread;
		String name;
		String mat;
		String templvl;
		String[] lvl1;
		String[] lvl2;
		String[] lvl3;
		int lvl;
		wonders = new Wonder[7];
		Scanner kb = new Scanner(new File("Wonders.txt"));
		while (kb.hasNextLine()) {
			fileread = kb.nextLine().split(" ");
			templvl = fileread[0];
			lvl = Integer.parseInt(templvl);
			mat = fileread[1];
			name = fileread[2];
			lvl1 = fileread[3].split("&");
			lvl2 = fileread[4].split("&");
			lvl3 = fileread[5].split("&");
			if (name.equalsIgnoreCase("alexandria")) {
				Wonder alex = new AlexandriaWonder(lvl, mat, name, lvl1, lvl2, lvl3);
				wonders[0] = alex;

			}
			else if (name.equalsIgnoreCase("babylon")) {
				Wonder baby = new BabylonWonder(lvl, mat, name, lvl1, lvl2, lvl3);
				wonders[1] = baby;

			}
			else if (name.equalsIgnoreCase("ephesos")) {
				Wonder ephes = new EphesosWonder(lvl, mat, name, lvl1, lvl2, lvl3);
				wonders[2] = ephes;

			}
			else if (name.equalsIgnoreCase("gizah")) {
				Wonder g = new GizahWonder(lvl, mat, name, lvl1, lvl2, lvl3);
				wonders[3] = g;

			}
			else if (name.equalsIgnoreCase("halikarnassus")) {
				Wonder hs = new HalikarnassusWonder(lvl, mat, name, lvl1, lvl2, lvl3);
				wonders[4] = hs;

			}
			else if (name.equalsIgnoreCase("olympia")) {
				Wonder c = new OlympiaWonder(lvl, mat, name, lvl1, lvl2, lvl3);
				wonders[5] = c;

			}
			else {
				Wonder road = new RhodosWonder(lvl, mat, name, lvl1, lvl2, lvl3);
				wonders[6] = road;
			}
		}
	}
	
	public Wonder[] getWonders()
	{
		return wonders;
	}

	public void dealCards() {
		ArrayList<Card> temp = currentAge;
		Collections.shuffle(temp);
		if (age == 3) {
			ArrayList<Card> guilds = new ArrayList<Card>();
			for (int i = 0; i < temp.size(); i++) {
				if (temp.get(i).getType().equals("Guild")) {
					guilds.add(temp.get(i));
				}
			}
			for (int i = 0; i < guilds.size() / 2; i++) {
				temp.remove(guilds.get(i));
			}

		}
		for (int i = 0; i < 3; i++) {
			ArrayList<Card> temp2 = new ArrayList<Card>();
			for (int j = 0; j < 7; j++) {
				temp2.add(temp.get(j + i * 7));
			}
			deck.put(i, temp2);
		}
	}

	public void chosenWonders(ArrayList<String> w) {
		for (int i = 0; i < allPlayers.length; i++) {
			int pos = -1;
			if(w.get(i).equalsIgnoreCase("alexandriaA"))
				pos = 0;
			else if(w.get(i).equalsIgnoreCase("babylonA"))
				pos = 1;
			else if(w.get(i).equalsIgnoreCase("ephesosA"))
				pos = 2;
			else if(w.get(i).equalsIgnoreCase("gizahA"))
				pos = 3;
			else if(w.get(i).equalsIgnoreCase("halikarnassusA"))
				pos = 4;
			else if(w.get(i).equalsIgnoreCase("olympiaA"))
				pos = 5;
			else if(w.get(i).equalsIgnoreCase("rhodosA"))
				pos = 6;
			
			allPlayers[i].setWonder(wonders[pos]);
		}
	}

	public void militaryBattles() {
		int[] militaryProwess = new int[3];
		for (int i = 0; i < allPlayers.length; i++) {
			ArrayList<Card> temp = allPlayers[i].getHand().get("Military");
			for (int j = 0; j < temp.size(); j++) {
				militaryProwess[i] += ((MilitaryCard) temp.get(j)).getCardWorth();
			}
		}
		if (militaryProwess[0] < militaryProwess[1]) {
			allPlayers[0].addToLosses(1);
			allPlayers[1].addToWins(1, age);
		} else if (militaryProwess[0] > militaryProwess[1]) {
			allPlayers[1].addToLosses(1);
			allPlayers[0].addToWins(1, age);
		}
		if (militaryProwess[1] < militaryProwess[2]) {
			allPlayers[1].addToLosses(1);
			allPlayers[2].addToWins(1, age);
		} else if (militaryProwess[1] > militaryProwess[2]) {
			allPlayers[2].addToLosses(1);
			allPlayers[1].addToWins(1, age);
		}
		if (militaryProwess[0] < militaryProwess[2]) {
			allPlayers[0].addToLosses(1);
			allPlayers[2].addToWins(1, age);
		} else if (militaryProwess[0] > militaryProwess[2]) {
			allPlayers[2].addToLosses(1);
			allPlayers[0].addToWins(1, age);
		}
	}

	public void upgradeWonder(Card rand) {
		allPlayers[turn].buildWonder(rand);
		removeCard(rand);
	}

	public boolean canBuildWonder() {
		System.out.println(allPlayers[turn].getMaterials());
		String[] mats = new String[0];
		if(allPlayers[turn].getWonder().getCurrentLevel() == 0)
			mats = allPlayers[turn].getWonder().getLVLOne();
		else if(allPlayers[turn].getWonder().getCurrentLevel() == 1)
			mats = allPlayers[turn].getWonder().getLVLTwo();
		else if(allPlayers[turn].getWonder().getCurrentLevel() == 2)
			mats = allPlayers[turn].getWonder().getLVLThree();
		Card temp = new Card(mats);
		return isPlayable(temp);
	}

	public boolean actionChosen(int choice, Card c) {
		if (choice == 1 && canBuildWonder()) {
			upgradeWonder(c);
			removeCard(c);
			return true;
		} else if (choice == 2 && isPlayable(c) || tradable(c)) {
			if(tradable(c))
				trade(c);
			allPlayers[turn].addToHand(c);
			removeCard(c);
			allPlayers[turn].updateFree(c);
			allPlayers[turn].updateMats();
			cardEffects(c);
			return true;
		} else if (choice == 3) {
			discard.add(c);
			allPlayers[turn].addCoins(3);
			removeCard(c);
			return true;
		}
		return false;
		// i think its done
	}
	
	public void cardEffects(Card c)
	{
		if(c.getName().equals("Vineyard")) 
		{
			for(int i = 0; i < allPlayers.length; i++)
			{
				ArrayList<Card> brown = allPlayers[i].getHand().get("Resource");
						for(int j = brown.size() -1 ; j > -1; j--)
							if(brown.get(j).getName().equals("Glassworks") || brown.get(j).getName().equals("Press") || brown.get(j).getName().equals("Loom"))
								brown.remove(j);
						allPlayers[turn].addCoins(brown.size());
			}
		}
		else if(c.getName().equals("Haven")) 
		{
			ArrayList<Card> brown = allPlayers[turn].getHand().get("Resource");
					for(int j = brown.size() -1 ; j > -1; j--)
						if(brown.get(j).getName().equals("Glassworks") || brown.get(j).getName().equals("Press") || brown.get(j).getName().equals("Loom"))
							brown.remove(j);
					allPlayers[turn].addCoins(brown.size());
		}
		else if(c.getName().equals("Lighthouse")) 
		{
			ArrayList<Card> brown = allPlayers[turn].getHand().get("Commerce/Trade");
			for(int j = brown.size() -1 ; j > -1; j--)
				if(brown.get(j).getName().equals("Alexandria"))
					brown.remove(j);
			allPlayers[turn].addCoins(brown.size());
		}
		else if(c.getName().equals("Arena"))
		{
			allPlayers[turn].addCoins(allPlayers[turn].getWonder().getCurrentLevel() * 3);
		}
	}
	
	public void lvl2() {
		if(allPlayers[turn].getWonder().getCurrentLevel()!= 2) {
			System.out.println("NOT ON LEVEL 2");
		}
		else
			if(allPlayers[turn].getWonder().getName().equalsIgnoreCase("Alexandria")) {
				String[] mats = {"Clay", "Stone", "Ore", "Timber"};
				Card c = new CommercialCard(0, "Commerce/Trade", "Alexandria", "NULL", "NULL", new String[1], mats, 0, true);
				allPlayers[turn].addToHand(c);
			}
			else if(allPlayers[turn].getWonder().getName().equalsIgnoreCase("Ephesos")) {
				allPlayers[turn].addCoins(9);
			}
			else if(allPlayers[turn].getWonder().getName().equalsIgnoreCase("Halikarnassus"))
			{
				Card toAdd = new Card();
				for(int z = 0; z < discard.size(); z++)
					if(isPlayable(discard.get(z)))
						toAdd = discard.get(z);
				allPlayers[turn].addToHand(toAdd);
			}
		}
	
	public boolean isPlayable(Card c) {
		Player p = allPlayers[turn];
		String[] costs = c.getCost();
		if(costs[0].equals("NULL"))
			return true;
		TreeMap<String, ArrayList<Card>> hand = p.getHand();
		ArrayList<Card> temp = new ArrayList<>();
		if(!(c.getName() == null))
			temp = hand.get(c.getType());
		if(!temp.isEmpty())
		{
			for(int i = 0; i < temp.size(); i++)
			{
				if(temp.get(i).getName().equals(c.getName()))
					return false;
			}
		}
		ArrayList<String> lol = p.getFreeBuilds();
		for(int i = 0; i < lol.size(); i++)
		{
			if(lol.get(i).equals(c.getName()))
				return true;
		}
		if(costs[0].equals("Coin"))
		{
			if(p.getCoins() < costs.length)
				return false;
			else
			{
				allPlayers[turn].addCoins(-1);
				return true;
			}
		}
		else
		{
			TreeMap<String, Integer> materials = p.getMaterials();
			ArrayList<String> trade = new ArrayList<>();
			for (int i = 0; i < costs.length; i++) {
				if (materials.get(costs[i]) == 0)
					trade.add(costs[i]);
				else {
					materials.put(costs[i], materials.get(costs[i]) - 1);
				}
			}
			if (trade.isEmpty())
				return true;
			if (choices(trade))
				return true;
			return false;
		}
		
		// TODO
	}

	public boolean tradable(Card c) {
		int coins = allPlayers[turn].getCoins();
		int cost = 0;
		ArrayList<String> matsNeeded = new ArrayList<>();
		ArrayList<String> ePlayer = new ArrayList<>();
		ArrayList<String> wPlayer = new ArrayList<>();
		ArrayList<String> player = new ArrayList<>();
		TreeMap<String, Integer> temp = new TreeMap<>();
		temp = allPlayers[(turn+1) % 3].getMaterials();
		Set<String> temp2 = temp.keySet();
		Iterator<String> itr = temp2.iterator();
		while(itr.hasNext())
		{
			String key = itr.next();
			int amt = temp.get(key);
			for(int i = 0; i < amt; i++)
			{
				ePlayer.add(key);
			}
		}
		if(turn - 1 == -1)
			temp = allPlayers[2].getMaterials();
		else
			temp = allPlayers[turn-1].getMaterials();
		temp2 = temp.keySet();
		itr = temp2.iterator();
		while(itr.hasNext())
		{
			String key = itr.next();
			int amt = temp.get(key);
			for(int i = 0; i < amt; i++)
			{
				wPlayer.add(key);
			}
		}
		String[] costs = c.getCost();
		if (costs[0].equals("NULL"))
			return false;
		if (costs[0].equals("Coin"))
			return false;
		TreeMap<String, Integer> materials = allPlayers[turn].getMaterials();
		if (!materials.isEmpty())
		{
			for (int i = 0; i < costs.length; i++) {
				if (materials.get(costs[i]) == 0)
					matsNeeded.add(costs[i]);
				else {
					materials.put(costs[i], materials.get(costs[i]) - 1);
				}
			}
		}
		
		matsNeeded = getMatsNeeded(matsNeeded);
		boolean grayCoin = false, eTP = false, wTP = false;
		ArrayList<Card> comm = allPlayers[turn].getHand().get("Commerce/Trade");
		
		for(int i = comm.size()-1; i > -1; i--)
		{
			if(!(comm.get(i).getName().equals("EastTradingPost") || comm.get(i).getName().equals("WestTradingPost") || comm.get(i).getName().equals("Marketplace")))
				comm.remove(i);
			else if(comm.get(i).getName().equals("Marketplace"))
				grayCoin = true;
			else if(comm.get(i).getName().equals("EastTradingPost"))
				eTP = true;
			else if(comm.get(i).getName().equals("WestTradingPost"))
				wTP = true;
		}
			
		for(int i = matsNeeded.size() -1; i > -1; i--)
		{
			if(matsNeeded.get(i).equals("Loom") || matsNeeded.get(i).equals("Papyrus") || matsNeeded.get(i).equals("Glass"))
			{
				if(!wPlayer.isEmpty() && wPlayer.contains(matsNeeded.get(i)))
				{
					if(grayCoin)
					{
						cost += 1;
						wPlayer.remove(matsNeeded.get(i));
						matsNeeded.remove(i);
					}
					else
					{
						cost += 2;
						wPlayer.remove(matsNeeded.get(i));
						matsNeeded.remove(i);
					}
				}
				else if(!ePlayer.isEmpty() && ePlayer.contains(matsNeeded.get(i)))
				{
					if(grayCoin)
					{
						cost += 1;
						ePlayer.remove(matsNeeded.get(i));
						matsNeeded.remove(i);
					}
					else
					{
						cost += 2;
						ePlayer.remove(matsNeeded.get(i));
						matsNeeded.remove(i);
					}
				}
				else
				{
					return false;
				}
			}
			else
			{
				if(!wPlayer.isEmpty() && wPlayer.contains(matsNeeded.get(i)))
				{
					if(wTP)
					{
						cost += 1;
						wPlayer.remove(matsNeeded.get(i));
						matsNeeded.remove(i);
					}
					else
					{
						cost += 2;
						wPlayer.remove(matsNeeded.get(i));
						matsNeeded.remove(i);
					}
				}
				else if(!ePlayer.isEmpty() && ePlayer.contains(matsNeeded.get(i)))
				{
					if(eTP)
					{
						cost += 1;
						ePlayer.remove(matsNeeded.get(i));
						matsNeeded.remove(i);
					}
					else
					{
						cost += 2;
						ePlayer.remove(matsNeeded.get(i));
						matsNeeded.remove(i);
					}
				}
				else
				{
					return false;
				}
			}
			//I think its done
		}
		if(coins >= cost)
			return true;
		return false;
	}
	
	public void trade(Card c)
	{
		int coins = allPlayers[turn].getCoins();
		int cost = 0;
		ArrayList<String> matsNeeded = new ArrayList<>();
		ArrayList<String> ePlayer = new ArrayList<>();
		ArrayList<String> wPlayer = new ArrayList<>();
		ArrayList<String> player = new ArrayList<>();
		TreeMap<String, Integer> temp = new TreeMap<>();
		temp = allPlayers[(turn+1) % 3].getMaterials();
		Set<String> temp2 = temp.keySet();
		Iterator<String> itr = temp2.iterator();
		while(itr.hasNext())
		{
			String key = itr.next();
			int amt = temp.get(key);
			for(int i = 0; i < amt; i++)
			{
				ePlayer.add(key);
			}
		}
		temp2 = temp.keySet();
		if(turn - 1 == -1)
			temp = allPlayers[2].getMaterials();
		else
			temp = allPlayers[turn-1].getMaterials();
		itr = temp2.iterator();
		while(itr.hasNext())
		{
			String key = itr.next();
			int amt = temp.get(key);
			for(int i = 0; i < amt; i++)
			{
				wPlayer.add(key);
			}
		}
		String[] costs = c.getCost();
		TreeMap<String, Integer> materials = allPlayers[turn].getMaterials();
		for (int i = 0; i < costs.length; i++) {
			if (materials.get(costs[i]) == 0)
				matsNeeded.add(costs[i]);
			else {
				materials.put(costs[i], materials.get(costs[i]) - 1);
			}
		}
		matsNeeded = getMatsNeeded(matsNeeded);
		boolean grayCoin = false, eTP = false, wTP = false;
		ArrayList<Card> comm = allPlayers[turn].getHand().get("Commerce/Trade");
		for(int i = comm.size()-1; i > -1; i--)
		{
			if(!(comm.get(i).getName().equals("EastTradingPost") || comm.get(i).getName().equals("WestTradingPost") || comm.get(i).getName().equals("Marketplace")))
				comm.remove(i);
			else if(comm.get(i).getName().equals("Marketplace"))
				grayCoin = true;
			else if(comm.get(i).getName().equals("EastTradingPost"))
				eTP = true;
			else if(comm.get(i).getName().equals("WestTradingPost"))
				wTP = true;
		}
			
		for(int i = matsNeeded.size() -1; i > -1; i--)
		{
			if(matsNeeded.get(i).equals("Loom") || matsNeeded.get(i).equals("Papyrus") || matsNeeded.get(i).equals("Glass"))
			{
				if(!wPlayer.isEmpty() && wPlayer.contains(matsNeeded.get(i)))
				{
					if(grayCoin)
					{
						cost += 1;
						wPlayer.remove(matsNeeded.get(i));
						matsNeeded.remove(i);
						if(turn - 1 == -1)
							allPlayers[2].addCoins(1);
						else
							allPlayers[turn-1].addCoins(1);
					}
					else
					{
						cost += 2;
						wPlayer.remove(matsNeeded.get(i));
						matsNeeded.remove(i);
						if(turn - 1 == -1)
							allPlayers[2].addCoins(i);
						else
							allPlayers[turn-1].addCoins(2);
					}
				}
				else if(!ePlayer.isEmpty() && ePlayer.contains(matsNeeded.get(i)))
				{
					if(grayCoin)
					{
						cost += 1;
						ePlayer.remove(matsNeeded.get(i));
						matsNeeded.remove(i);
						allPlayers[(turn+1) % 3].addCoins(1);
						
					}
					else
					{
						cost += 2;
						ePlayer.remove(matsNeeded.get(i));
						matsNeeded.remove(i);
						allPlayers[(turn+1) % 3].addCoins(2);
					}
				}
			}
			else
			{
				if(!wPlayer.isEmpty() && wPlayer.contains(matsNeeded.get(i)))
				{
					if(wTP)
					{
						cost += 1;
						wPlayer.remove(matsNeeded.get(i));
						matsNeeded.remove(i);
						if(turn - 1 == -1)
							allPlayers[2].addCoins(1);
						else
							allPlayers[turn-1].addCoins(2);
					}
					else
					{
						cost += 2;
						wPlayer.remove(matsNeeded.get(i));
						matsNeeded.remove(i);
						if(turn - 1 == -1)
							allPlayers[2].addCoins(1);
						else
							allPlayers[turn-1].addCoins(2);
					}
				}
				else if(!ePlayer.isEmpty() && ePlayer.contains(matsNeeded.get(i)))
				{
					if(eTP)
					{
						cost += 1;
						ePlayer.remove(matsNeeded.get(i));
						matsNeeded.remove(i);
						allPlayers[(turn+1) % 3].addCoins(2);
					}
					else
					{
						cost += 2;
						ePlayer.remove(matsNeeded.get(i));
						matsNeeded.remove(i);
						allPlayers[(turn+1) % 3].addCoins(2);
					}
				}
			}
		}
		allPlayers[turn].setCoins(coins - cost);
	}

	public void removeCard(Card c) {
		ArrayList<Card> temp = deck.get(turn);
		temp.remove(c);
		deck.put(turn, temp);
	}

	public boolean choices(ArrayList<String> choice) {
		Player p = allPlayers[turn];
		TreeMap<String, ArrayList<Card>> temp = p.getHand();
		if(p.getHand().isEmpty() || choice.isEmpty())
		{
			return true;
		}
		//Checking
		for(int i = 0; i < choice.size(); i++)
		{
			if(!(choice.get(i).equals("Papyrus") || choice.get(i).equals("Timber") || choice.get(i).equals("Ore") || choice.get(i).equals("Stone") || choice.get(i).equals("Clay") || choice.get(i).equals("Glass") || choice.get(i).equals("Loom")))
					System.out.println("OOF"); 
		}
		//Remove later maybe
		ArrayList<MaterialCard> choiceArr = new ArrayList<MaterialCard>();
		ArrayList<Card> tempArr = temp.get("Resource");
		if(temp.get("Resource").isEmpty())
		{
			return false;
		} 
		for (int i = 0; i < tempArr.size(); i++) {
			if (((MaterialCard) tempArr.get(i)).isChoice()) {
				choiceArr.add((MaterialCard) tempArr.get(i));
			}
		}
		for (int j = choice.size() - 1; j > -1; j--) {
			for (int i = 0; i < choiceArr.size(); i++) {
				String[] materials = ((MaterialCard)choiceArr.get(i)).getMaterial();
				for (int k = 0; k < materials.length; k++) {
					if (choice.isEmpty())
						break;
					if (materials[k].equals(choice.get(j)))
					{
						choice.remove(j);
						break;
					}
				}
			}
		}
		tempArr = temp.get("Commerce/Trade");
		if(temp.get("Commerce/Trade").isEmpty())
		{
			return false;
		}
		ArrayList<CommercialCard> mats = new ArrayList<>();
		for (int i = 0; i < tempArr.size(); i++) {
			if (tempArr.get(i).getName().equals("Caravansery") || tempArr.get(i).getName().equals("Forum") || tempArr.get(i).getName().equals("Alexandria")) {
				mats.add((CommercialCard) tempArr.get(i));
			}
		}
		for (int i = 0; i < choiceArr.size(); i++) {
			String[] materials = ((MaterialCard)choiceArr.get(i)).getMaterial();
			int count= 0;
			boolean used = false;
			while(!used && count < materials.length)
			{
				if(choice.isEmpty())
					return false;
				for(int c = choice.size()-1; c > -1; c--)
				{
					if(choice.get(c).equals(materials[count]))
					{
						choice.remove(c);
						used = true;
					}
				}
				count++;
			}
		}
		// I think its finished?
		return choice.isEmpty();
	}
	public ArrayList<String> getMatsNeeded(ArrayList<String> choice) {
		Player p = allPlayers[turn];
		TreeMap<String, ArrayList<Card>> temp = p.getHand();
		if(p.getHand().isEmpty() || choice.isEmpty())
		{
			return choice;
		}
		//Checking
		for(int i = 0; i < choice.size(); i++)
		{
			if(!(choice.get(i).equals("Papyrus") || choice.get(i).equals("Timber") || choice.get(i).equals("Ore") || choice.get(i).equals("Stone") || choice.get(i).equals("Clay") || choice.get(i).equals("Glass") || choice.get(i).equals("Loom")))
					System.out.println("OOF"); 
		}
		//Remove later maybe
		ArrayList<MaterialCard> choiceArr = new ArrayList<MaterialCard>();
		ArrayList<Card> tempArr = temp.get("Resource");
		if(temp.get("Resource").isEmpty())
		{
			return choice;
		} 
		for (int i = 0; i < tempArr.size(); i++) {
			if (((MaterialCard) tempArr.get(i)).isChoice()) {
				choiceArr.add((MaterialCard) tempArr.get(i));
			}
		}
		
		if (choiceArr.isEmpty())
			return choice;
		
		System.out.println(choice);
		System.out.println(choiceArr);
		
		
		for (int i = 0; i < choiceArr.size(); i++) {
			String[] materials = ((MaterialCard)choiceArr.get(i)).getMaterial();
			int count= 0;
			boolean used = false;
			while(!used && count < materials.length)
			{
				if(choice.isEmpty())
					return choice;
				for(int c = choice.size()-1; c > -1; c--)
				{
					if(choice.get(c).equals(materials[count]))
					{
						choice.remove(c);
						used = true;
					}
				}
				count++;
			}
		}
		tempArr = temp.get("Commerce/Trade");
		if(temp.get("Commerce/Trade").isEmpty())
		{
			return choice;
		}
		ArrayList<CommercialCard> mats = new ArrayList<>();
		for (int i = 0; i < tempArr.size(); i++) {
			if (tempArr.get(i).getName().equals("Caravansery") || tempArr.get(i).getName().equals("Forum") || tempArr.get(i).getName().equals("Alexandria")) {
				mats.add((CommercialCard) tempArr.get(i));
			}
		}
		if (mats.size() >= choice.size()) {
			for (int j = choice.size() - 1; j > -1; j--) {
				for (int i = 0; i < mats.size(); i++) {
					String[] materials = mats.get(i).getMats();
					for (int f = 0; i < materials.length; f++) {
						if (materials[f].equals(choice.get(j)))
							choice.remove(j);
					}
				}
			}
		}
		return choice;
	}
	public ArrayList<Card> getDiscard()
	{
		return discard;
	}
}
