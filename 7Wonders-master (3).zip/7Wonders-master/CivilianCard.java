public class CivilianCard extends Card{
	private int vPWorth;
	public CivilianCard(int ages, String types, String names, String upgrades, String costs, int worth) {
		super(ages, types, names, upgrades, costs);
		setVPWorth(worth);
	}
	public void setVPWorth(int worth)
	{
		vPWorth = worth;
	}
	public int getVPWorth()
	{
		return vPWorth;
	}
	public void print()
	{
		super.print();
		System.out.print(", VP: " + vPWorth);
	}
}