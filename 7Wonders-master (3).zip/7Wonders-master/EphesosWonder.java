

public class EphesosWonder extends Wonder{
	private int extraCoin;
	public EphesosWonder(int lvl, String mat, String named, String[] level1, String[] level2, String[] level3) {
		super(lvl, mat, named, level1, level2, level3);
	}
	public void setExtraCoin(int extraCoin) {
		this.extraCoin = extraCoin;
	}
	public int getExtraCoin() {
		return extraCoin;
	}
}