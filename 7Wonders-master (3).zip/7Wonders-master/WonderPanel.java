import java.io.File;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.concurrent.TimeUnit;
import java.util.TreeMap;

public class WonderPanel extends JPanel
{
	private ArrayList<BufferedImage> wonders;
	private BufferedImage redX;
	private String wonderChosen;
	private int x, y, currentPlayer;
	private TreeMap<String, Boolean> redXMap;
	private TreeMap<String, Integer> wonderChoosing;
	
	
	public WonderPanel()
	{
		super();
		
		redXMap = new TreeMap<String, Boolean>();
		resetWonderChoosing();
		currentPlayer = 0;
		wonderChosen = "";
		wonders = new ArrayList<BufferedImage>();
		addMouseListener(new MouseAdapter()
		{
			public void mousePressed(MouseEvent e)
			{
				x = e.getX();
				y = e.getY();
			}
		});
		
		try {
			redX = ImageIO.read(new File("Other/redX.png"));
			BufferedImage wonder1 = ImageIO.read(new File("WonderPNG/rhodosA.png"));
			wonders.add(wonder1);
			BufferedImage wonder2 = ImageIO.read(new File("WonderPNG/gizahA.png"));
			wonders.add(wonder2);
			BufferedImage wonder3 = ImageIO.read(new File("WonderPNG/olympiaA.png"));
			wonders.add(wonder3);
			BufferedImage wonder4 = ImageIO.read(new File("WonderPNG/halikarnassusA.png"));
			wonders.add(wonder4);
			BufferedImage wonder5 = ImageIO.read(new File("WonderPNG/ephesosA.png"));
			wonders.add(wonder5);
			BufferedImage wonder6 = ImageIO.read(new File("WonderPNG/babylonA.png"));
			wonders.add(wonder6);
			BufferedImage wonder7 = ImageIO.read(new File("WonderPNG/alexandriaA.png"));
			wonders.add(wonder7);
		}
		catch(Exception e)
		{
			System.out.println("error");
		}
	}
	
	public void setPlayer(int num)
	{
		currentPlayer = num;
		x = 0;
		y = 0;
	}
	
	public String chooseWonder()
	{
		String theRet = "";
		String justChosen = "";
		while (true)
		{
			while (x == 0 && y == 0)
			{
				try {
					TimeUnit.MICROSECONDS.sleep(100);
				}
				catch(Exception e) {
					System.out.println("error");
				}
			}
		
			if (x < getWidth() / 2 && y < getHeight() / 4 && !redXMap.containsKey("rhodosA"))
			{
				wonderChoosing.put("rhodosA", wonderChoosing.get("rhodosA") + 1);
				justChosen = "rhodosA";
			}
			else if (x > getWidth() / 2 && y < getHeight() / 4 && !redXMap.containsKey("gizahA"))
			{
				wonderChoosing.put("gizahA", wonderChoosing.get("gizahA") + 1);
				justChosen = "gizahA";
			}
			else if (x < getWidth() / 2 && y < getHeight() / 4 * 2  && y > getHeight() / 4 && !redXMap.containsKey("olympiaA"))
			{
				wonderChoosing.put("olympiaA", wonderChoosing.get("olympiaA") + 1);
				justChosen = "olympiaA";
			}
			else if (x > getWidth() / 2 && y < getHeight() / 4 * 2 && y > getHeight() / 4 && !redXMap.containsKey("halikarnassusA"))
			{
				wonderChoosing.put("halikarnassusA", wonderChoosing.get("halikarnassusA") + 1);
				justChosen = "halikarnassusA";
			}
			else if (x < getWidth() / 2 && y < getHeight() / 4 * 3 && y > getHeight() / 4 * 2 && !redXMap.containsKey("ephesosA"))
			{
				wonderChoosing.put("ephesosA", wonderChoosing.get("ephesosA") + 1);
				justChosen = "ephesosA";
			}
			else if (x > getWidth() / 2 && y < getHeight() / 4 * 3 && y > getHeight() / 4 * 2 && !redXMap.containsKey("babylonA"))
			{
				wonderChoosing.put("babylonA", wonderChoosing.get("babylonA") + 1);
				justChosen = "babylonA";
			}
			else if (x < getWidth() / 2 && y > getHeight() / 4 * 3 && y > getHeight() / 4 * 3 && !redXMap.containsKey("alexandriaA"))
			{
				wonderChoosing.put("alexandriaA", wonderChoosing.get("alexandriaA") + 1);
				justChosen = "alexandriaA";
			}
			repaint();
			
			for (String key : wonderChoosing.keySet())
			{
				if (key.equals(justChosen))
					continue;
				else
					wonderChoosing.put(key, 0);
			}

			if (x < getWidth() / 2 && y < getHeight() / 4 && !redXMap.containsKey("rhodosA") && wonderChoosing.get("rhodosA") == 2 && x != 0 && y != 0)
			{
				theRet = ("rhodosA");
				redXMap.put("rhodosA", true);
				break;
			}
			else if (x > getWidth() / 2 && y < getHeight() / 4 && !redXMap.containsKey("gizahA") && wonderChoosing.get("gizahA") == 2 && x != 0 && y != 0)
			{
				theRet = ("gizahA");
				redXMap.put("gizahA", true);
				break;
			}
			else if (x < getWidth() / 2 && y < getHeight() / 4 * 2 && !redXMap.containsKey("olympiaA") && y > getHeight() / 4 && wonderChoosing.get("olympiaA") == 2)
			{
				theRet = ("olympiaA");
				redXMap.put("olympiaA", true);
				break;
			}
			else if (x > getWidth() / 2 && y < getHeight() / 4 * 2 && !redXMap.containsKey("halikarnassusA") && y > getHeight() / 4 && wonderChoosing.get("halikarnassusA") == 2)
			{
				theRet = ("halikarnassusA");
				redXMap.put("halikarnassusA", true);
				break;
			}
			else if (x < getWidth() / 2 && y < getHeight() / 4 * 3 && !redXMap.containsKey("ephesosA") && y > getHeight() / 4 * 2 && wonderChoosing.get("ephesosA") == 2)
			{
				theRet = ("ephesosA");
				redXMap.put("ephesosA", true);
				break;
			}
			else if (x > getWidth() / 2 && y < getHeight() / 4 * 3 && !redXMap.containsKey("babylonA") && y > getHeight() / 4 * 2 && wonderChoosing.get("babylonA") == 2)
			{
				theRet = ("babylonA");
				redXMap.put("babylonA", true);
				break;
			}
			else if (x < getWidth() / 2 && y > getHeight() / 4 * 3 && !redXMap.containsKey("alexandriaA") && y > getHeight() / 4 * 3 && wonderChoosing.get("alexandriaA") == 2)
			{
				theRet = ("alexandriaA");
				redXMap.put("alexandriaA", true);
				break;
			}
			repaint();
			x = 0; y = 0;
		}
		
		resetWonderChoosing();

		
		return theRet;
	}
	
	public void resetWonderChoosing()
	{
		wonderChoosing = new TreeMap<String, Integer>();
		wonderChoosing.put("rhodosA", 0);
		wonderChoosing.put("gizahA", 0);
		wonderChoosing.put("olympiaA", 0);
		wonderChoosing.put("halikarnassusA", 0);
		wonderChoosing.put("ephesosA", 0);
		wonderChoosing.put("babylonA", 0);
		wonderChoosing.put("alexandriaA", 0);
	}
	
	public void paint(Graphics g)
	{
		Graphics2D g2 = (Graphics2D) g;
		String check = "";

		redX = resize(redX, this.getWidth() / 2, this.getHeight() / 4);
		int count = 0; int x = 0; int y = 0;
		for (int posi = 0; posi < wonders.size(); posi++)
		{
			BufferedImage thing = wonders.get(posi);
			thing = resize(thing, this.getWidth() / 2, this.getHeight() / 4);
			g.drawImage(thing, 0 + x, 0 + y, null);
		
			count++;
			if (count % 2 == 1)
			{
				x = this.getWidth() / 2;
			}
			else if (count % 2 == 0)
			{
				x = 0;
				int temp = count;
				if (count == 4)
					count--;
				else if (count == 6)
					count -= 2;
				
				y = (this.getHeight() / 4) * (count - 1);
				count = temp;
				
			}
		}
		
		Rectangle rect = new Rectangle(this.getWidth() / 2, this.getHeight() / 4 * 3, this.getWidth() / 2, this.getHeight() / 4);
		g2.setColor(Color.gray);
		g2.fill(rect);
		g.setColor(Color.RED);
		g.setFont(new Font("Arial", Font.BOLD, (this.getHeight()) / 29 + (this.getWidth() / 29)));
		g.drawString("Player Choosing: " + currentPlayer, this.getWidth() / 2, this.getHeight() / 4 * 3 + this.getHeight() / 7);
		
		if (redXMap.size() > 0)
		{
			if (redXMap.containsKey("rhodosA"))
				g.drawImage(redX, 0, 0, null);
			if (redXMap.containsKey("gizahA"))
				g.drawImage(redX, this.getWidth() / 2, 0, null);
			if (redXMap.containsKey("olympiaA"))
				g.drawImage(redX, 0, this.getHeight() / 4, null);
			if (redXMap.containsKey("halikarnassusA"))
				g.drawImage(redX, this.getWidth() / 2, this.getHeight() / 4, null);
			if (redXMap.containsKey("ephesosA"))
				g.drawImage(redX, 0, this.getHeight() / 4 * 2, null);	
			if (redXMap.containsKey("babylonA"))
				g.drawImage(redX,  this.getWidth() / 2, this.getHeight() / 4 * 2, null);
			if (redXMap.containsKey("alexandriaA"))
				g.drawImage(redX, 0, this.getHeight() / 4 * 3, null);
		}
		
		if (wonderChoosing.containsValue(1))
		{
			for (String key : wonderChoosing.keySet())
				if (wonderChoosing.get(key) == 1)
					check = key;
			int outlineX = 0, outlineY = 0;
			
			if (check.equals("rhodosA"))
			{
				outlineX = 0;
				outlineY = 0;
			}
			else if (check.equals("gizahA"))
			{
				outlineX = getWidth() / 2;
				outlineY = 0;
			}
			else if (check.equals("olympiaA"))
			{
				outlineX = 0;
				outlineY = getHeight() / 4;
			}
			else if (check.equals("halikarnassusA"))
			{
				outlineX = getWidth() / 2;
				outlineY = getHeight() / 4;
			}
			else if (check.equals("ephesosA"))
			{
				outlineX = 0;
				outlineY = getHeight() / 2;
			}
			else if (check.equals("babylonA"))
			{
				outlineX = getWidth() / 2;
				outlineY = getHeight() / 2;
			}
			else if (check.equals("alexandriaA"))
			{
				outlineX = 0;
				outlineY = getHeight() / 4 * 3;
			}
			
			Rectangle outline = new Rectangle(outlineX, outlineY, getWidth() / 2, getHeight() / 4);
			g2.setColor(Color.YELLOW);
			g2.setStroke(new java.awt.BasicStroke(8));
			g2.draw(outline);
		}
	}
	
	public static BufferedImage resize(BufferedImage img, int newW, int newH)
	{ 
	    Image tmp = img.getScaledInstance(newW, newH, Image.SCALE_SMOOTH);
	    BufferedImage dimg = new BufferedImage(newW, newH, BufferedImage.TYPE_INT_ARGB);

	    Graphics2D g2d = dimg.createGraphics();
	    g2d.drawImage(tmp, 0, 0, null);
	    g2d.dispose();

	    return dimg;
	}  
}
