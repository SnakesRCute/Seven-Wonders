public class ScienceCard extends Card{
    private String types;
	public ScienceCard(int ages, String type, String names, String upgrades, String costs, String ty) {
		super(ages, type, names, upgrades, costs);
		setTypes(ty);
	}
	public void setTypes(String t){
		types = t;
	}
	public String getTypes() {
		return types;
	}
	public void print()
	{
		super.print();
		System.out.print(", TYPE: " + types);
	}
}