import java.util.TreeMap;

public class RhodosWonder extends Wonder{
	private int extraMilitary;
	public RhodosWonder(int lvl, String mat, String named, String[] level1, String[] level2, String[] level3) {
		super(lvl, mat, named, level1, level2, level3);
	}
	public int getExtraMilitary() {
		return extraMilitary;
	}
	public void setExtraMilitary(int extraMilitary) {
		this.extraMilitary = extraMilitary;
	}
}