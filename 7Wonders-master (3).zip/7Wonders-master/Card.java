import java.util.Arrays;

public class Card {
	private int age;
	private String name, type; 
	private String[] upgrade, cost;
	public Card()
	{
	}
	public Card(String[] costs)
	{
		cost = costs;
	}
	public Card(int ages, String typ, String names, String upgrades, String costs)
	{
		setType(typ);
		setAge(ages);
		setName(names);
		if(!upgrades.equals("NULL"))
		{
			if(upgrades.contains("&"))
			{
				setUpgrade(upgrades.split("&"));
			}
			else
			{
				String[] u = new String[1];
				u[0] = upgrades;
				setUpgrade(u);
			}
		}
		else
		{
			String[] u = new String[1];
			u[0] = upgrades;
			setUpgrade(u);
		}
		if(!costs.equals("NULL"))
		{
			if(costs.contains("&"))
			{
				setCost(costs.split("&"));
			}
			else
			{
				String[] c = new String[1];
				c[0] = costs;
				setCost(c);
			}
		}
		else
		{
			String[] c = new String[1];
			c[0] = "NULL";
			setCost(c);
		}
	}
	public void setAge(int a)
	{
		age = a;
	}
	public void setName(String n)
	{
		name = n;
	}
	public void setUpgrade(String[] u)
	{
		upgrade = u;
	}
	public void setCost(String[] c)
	{
		cost = c;
	}
	public int getAge()
	{
		return age;
	}
	public String getName()
	{
		return name;
	}
	public String[] getCost()
	{
		return cost;
	}
	public String[] getUpgrades()
	{
		return upgrade;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public boolean equals(Card c)
	{
		if(this.getName().equals(c.getName()))
			return true;
		return false;
	}
	public void print()
	{
		System.out.print("AGE: " + getAge() + ", NAME: " + getName() + ", COST: " + Arrays.toString(getCost()) + ", UPGRADE: " + Arrays.toString(getUpgrades()) + ", TYPE: " + getType());
	}
}
