import javax.swing.JFrame;

public class WonderFrame extends JFrame
{
	WonderPanel wondPanel;
	public WonderFrame()
	{
		super("Seven Wonders");
		
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setLayout(null);
		setVisible(true);

		wondPanel = new WonderPanel();
		wondPanel.setSize(1920, 1080);
		add(wondPanel);
	}
	
	public void setPlayer(int x)
	{
		wondPanel.setPlayer(x);
	}
	
	public WonderPanel getWondPanel()
	{
		return wondPanel;
	}
	
	public void makeInvis()
	{
		setVisible(false);
	}
}
