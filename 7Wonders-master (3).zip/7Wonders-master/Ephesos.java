import java.util.TreeMap;

public class Ephesos extends Wonder{
	private int extraCoin;
	public Ephesos(int lvl, String mat, String named, String bonuses, TreeMap<String, Integer> upgrade, int coin) {
		super(lvl, mat, named, bonuses, upgrade);
		setExtraCoin(coin);
	}
	public int getExtraCoin() {
		return extraCoin;
	}
	public void setExtraCoin(int extraCoin) {
		this.extraCoin = extraCoin;
	}
}
