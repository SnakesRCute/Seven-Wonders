import java.util.*;
import java.io.*;
public class Deck {
	private ArrayList<Card> age1;
	private ArrayList<Card> age2;
	private ArrayList<Card> age3;
	public Deck() throws IOException {
		String[] mats;
		age1 = new ArrayList<Card>();
		age2 = new ArrayList<Card>();
		age3 = new ArrayList<Card>();
		Scanner one = new Scanner(new File("Age1.txt"));
		Scanner two = new Scanner(new File("Age2.txt"));
		Scanner three = new Scanner(new File("Age3.txt"));
		for(int i = 0; i < 21; i++) {
			Card temp1 = new Card();
			Card temp2 = new Card();
			String[] oneA = one.nextLine().split(" ");
			String[] twoA = two.nextLine().split(" ");
			String ty1 = oneA[0].trim();
			String ty2 = twoA[0].trim();
			String fn1 = oneA[5].trim();
			String fn2 = twoA[5].trim();
			if(ty1.equalsIgnoreCase("Resource")) {
				if(fn1.contains("/")) {
					mats = fn1.split("/");
					temp1 = new MaterialCard(1, oneA[0], oneA[1].trim(), oneA[4].trim(), oneA[3].trim(), mats, true);
				}
				else if(fn1.contains("&")) {
					mats = fn1.split("&");
					temp1 = new MaterialCard(1, oneA[0], oneA[1].trim(), oneA[4].trim(), oneA[3].trim(), mats, false);
				}
				else {
					mats = new String[1];
					mats[0] = fn1;
					temp1 = new MaterialCard(1, oneA[0], oneA[1].trim(), oneA[4].trim(), oneA[3].trim(), mats, false);
				}
				
			}
			else if(ty1.equalsIgnoreCase("Military")) {
				int pts = Integer.parseInt(fn1);
				temp1 = new MilitaryCard(1, oneA[0], oneA[1].trim(), oneA[4].trim(), oneA[3].trim(), pts);
			}
			else if(ty1.equalsIgnoreCase("Civilian")) {
				int pts = Integer.parseInt(fn1);
				temp1 = new CivilianCard(1, oneA[0], oneA[1].trim(), oneA[4].trim(), oneA[3].trim(), pts);
			}
			else if(ty1.equalsIgnoreCase("Science"))
				temp1 = new ScienceCard(1, oneA[0], oneA[1].trim(), oneA[4].trim(), oneA[3].trim(), fn1);
			else if(ty1.equalsIgnoreCase("Commerce/Trade")) {
				String[] dirc;
				//String[] mats;
				if(fn1.contains("/")) {
					dirc = new String[2];
					dirc = fn1.split("/");
				}
				else {
					dirc = new String[1];
					dirc[0] = fn1;
				}
				if(oneA[6].contains("&"))
					mats = oneA[6].trim().split("&");
				else {
					mats = new String[1];
					mats[0] = oneA[6];
				}
				temp1 = new CommercialCard(1, oneA[0], oneA[1].trim(), oneA[4].trim(), oneA[3].trim(), dirc, mats, Integer.parseInt(oneA[7]), true);
			}
			age1.add(temp1);
			//////////////////////////////////////////////////AGE2////////////////////////////////////////////////////////////////////////////////////
			if(ty2.equalsIgnoreCase("Resource")) {
				if(fn2.contains("/")) {
					mats = fn2.split("/");
					temp2 = new MaterialCard(2, twoA[0], twoA[1].trim(), twoA[4].trim(), twoA[3].trim(), mats, true);
				}
				else if(fn2.contains("&")) {
					mats = fn2.split("&");
					temp2 = new MaterialCard(2, twoA[0], twoA[1].trim(), twoA[4].trim(), twoA[3].trim(), mats, false);
				}
				else {
					mats = new String[1];
					mats[0] = fn2;
					temp2 = new MaterialCard(2, twoA[0], twoA[1].trim(), twoA[4].trim(), twoA[3].trim(), mats, false);
				}
			}
			else if(ty2.equalsIgnoreCase("Military")) {
				int pts = Integer.parseInt(fn2);
				temp2 = new MilitaryCard(2, twoA[0], twoA[1].trim(), twoA[4].trim(), twoA[3].trim(), pts);
			}
			else if(ty2.equalsIgnoreCase("Civilian")) {
				int pts = Integer.parseInt(fn2);
				temp2 = new CivilianCard(2, twoA[0], twoA[1].trim(), twoA[4].trim(), twoA[3].trim(), pts);
			}
			else if(ty2.equalsIgnoreCase("Science")) {
				temp2 = new ScienceCard(2, twoA[0], twoA[1].trim(), twoA[4].trim(), twoA[3].trim(), fn2);
			}	
			else if(ty2.equalsIgnoreCase("Commerce/Trade")) {
				String[] dirc;
				//String[] mats;
				if(fn2.contains("/")) {
					dirc = new String[2];
					dirc = fn2.split("/");
				}
				else {
					dirc = new String[1];
					dirc[0] = fn2;
				}
				if(twoA[6].contains("&"))
					mats = twoA[6].trim().split("&");
				else {
					mats = new String[1];
					mats[0] = twoA[6];
				}
				temp2 = new CommercialCard(2, twoA[0], twoA[1].trim(), twoA[4].trim(), twoA[3].trim(), dirc, mats, Integer.parseInt(twoA[7]), true);
			}
			age2.add(temp2);
		}
		////////////////////////////////////////////////////////AGE3/////////////////////////////////////////////////////////////////////////////////
		for(int o = 0; o < 26; o++) {
			Card temp3 = new Card();
			String[] threeA = three.nextLine().split(" ");
			String ty3 = threeA[0].trim();
			String fn3 = threeA[5].trim();
			if(ty3.equalsIgnoreCase("Resource")) {
				if(fn3.contains("/")) {
					mats = fn3.split("/");
					temp3 = new MaterialCard(3, threeA[0], threeA[1].trim(), threeA[4].trim(), threeA[3].trim(), mats, true);
				}
				else if(fn3.contains("&")) {
					mats = fn3.split("&");
					temp3 = new MaterialCard(3, threeA[0], threeA[1].trim(), threeA[4].trim(), threeA[3].trim(), mats, false);
				}
				else {
					mats = new String[1];
					mats[0] = fn3;
					temp3 = new MaterialCard(2, threeA[0], threeA[1].trim(), threeA[4].trim(), threeA[3].trim(), mats, false);
				}
			}
			else if(ty3.equalsIgnoreCase("Military")) {
				int pts = Integer.parseInt(fn3);
				temp3 = new MilitaryCard(3, threeA[0], threeA[1].trim(), threeA[4].trim(), threeA[3].trim(), pts);
			}
			else if(ty3.equalsIgnoreCase("Civilian")) {
				int pts = Integer.parseInt(fn3);
				temp3 = new CivilianCard(3, threeA[0], threeA[1].trim(), threeA[4].trim(), threeA[3].trim(), pts);
			}
			else if(ty3.equalsIgnoreCase("Science"))
				temp3 = new ScienceCard(3, threeA[0], threeA[1].trim(), threeA[4].trim(), threeA[3].trim(), fn3);
			else if(ty3.equalsIgnoreCase("Commerce/Trade")) {
				String[] dirc;
				//String[] mats;
				if(fn3.contains("/")) {
					dirc = new String[2];
					dirc = fn3.split("/");
				}
				else {
					dirc = new String[1];
					dirc[0] = fn3;
				}
				if(threeA[6].contains("&"))
					mats = threeA[6].trim().split("&");
				else {
					mats = new String[1];
					mats[0] = threeA[6];
				}
				temp3 = new CommercialCard(3, threeA[0], threeA[1].trim(), threeA[4].trim(), threeA[3].trim(), dirc, mats, Integer.parseInt(threeA[7]), true);
			}
			else {
				String[] dirc;
				//String[] mats;
				if(threeA[6].contains("/")) {
					dirc = new String[2];
					dirc = threeA[6].split("/");
				}
				else {
					dirc = new String[1];
					dirc[0] = threeA[6];
				}
				temp3 = new GuildCard(3, threeA[0], threeA[1].trim(), threeA[4].trim(), threeA[3].trim(), Integer.parseInt(fn3), dirc, threeA[7], threeA[8]);
			}
			age3.add(temp3);
		}
	}
	public ArrayList<Card> getAge1() {	
		return age1;
	}
	public ArrayList<Card> getAge2() {	
		return age2;
	}
	public ArrayList<Card> getAge3() {	
		return age3;
	}
}
