import java.util.TreeMap;

public class Gizah extends Wonder{
	private int extraVP;
	public Gizah(int lvl, String mat, String named, String bonuses, TreeMap<String, Integer> upgrade, int extra) {
		super(lvl, mat, named, bonuses, upgrade);
		setExtraVP(extra);
	}
	public int getExtraVP() {
		return extraVP;
	}
	public void setExtraVP(int extraVP) {
		this.extraVP = extraVP;
	}
}
