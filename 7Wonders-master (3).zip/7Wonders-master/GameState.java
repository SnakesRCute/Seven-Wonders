import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeMap;

public class GameState
{
	private WonderFrame wonderFrame;
	private GameFrame mainFrame;
	private ArrayList<String> choices;
	private Board board;
	
	public GameState()
	{
		wonderFrame = new WonderFrame();
		wonderFrame.setSize(1920, 1080);
		choices = new ArrayList<String>();
		try {
			board = new Board();
		}
		catch (Exception e) {
			System.out.println("error");
			//hello. 
		}
		for (int posi = 1; posi <= 3; posi++)
		{
			wonderFrame.getWondPanel().setPlayer(posi);
			choices.add(wonderFrame.getWondPanel().chooseWonder());
		}
		board.chosenWonders(choices);
		beginGame(choices);
	}
	
	public void beginGame(ArrayList<String> wonders)
	{
		mainFrame = new GameFrame();
		mainFrame.setSize(1920, 1080);
		wonderFrame.setVisible(false);
		mainFrame.getGamePanel().setPlayers(getBoard().getPlayers());
	}
	
	
	public void rotatePlayers()
	{
		String temp = choices.get(0);
		choices.remove(0);
		choices.add(temp);
	}
	
	public void setOptions()
	{
		mainFrame.getPanel().setOptions(board.getDeck().get(board.getTurn()), board.getTurn(), board.getPlayers(), board.getTurn());
	}
	public GameFrame getGameFrame()
	{
		return mainFrame;
	}
	public Board getBoard()
	{
		return board;
	}
	
	public TreeMap<Integer, Card> chooseCard()
	{
		return mainFrame.getPanel().makeAction(getBoard().getPlayers(),getBoard().getTurn());
	}
	
	public static void main(String[]args)
	{
		GameState state = new GameState();
		//Assign player wonders
		int x = 0;
		for(int age = 1; age <= 3; age++)
		{
			state.getBoard().createDeck();
			state.getBoard().dealCards();
			state.setOptions();
			for(int j = 0; j < 6; j++)
			{
				for(int i = 0; i < 3; i++)
				{
					state.getGameFrame().getGamePanel().addThisPlayersCards(state.getBoard().getPlayers()[state.getBoard().getTurn()]);
					state.setOptions();
					int action = 0;
					for (int posi : state.chooseCard().keySet())
						action = posi;
					Card c = state.getGameFrame().getPanel().getAction().get(action);
					
					while (state.getBoard().actionChosen(action, c) == false)
					{
						state.setOptions();
						for (int posi : state.chooseCard().keySet())
							action = posi;
						c = state.getGameFrame().getPanel().getAction().get(action);
					}
					
					Player[] arr = state.getBoard().getPlayers();
					state.getBoard().nextPlayer();
					if (action == 1)
						state.getGameFrame().getGamePanel().updateWonderUpgrade();
					state.getGameFrame().getGamePanel().rotatePlayers();
				}
				// DISPLAY THEIR CHOICES HERE
				Player[] players = state.getBoard().getPlayers();
				int turn = state.getBoard().getTurn();
				for(int i = 0; i < players.length; i++)
				{
					//display each
					state.getBoard().nextPlayer();
					turn = state.getBoard().getTurn();
				}
				state.getBoard().nextTurn();
			}
			state.getBoard().militaryBattles();
			if (age < 3)
			{
				state.getBoard().nextAge();
				state.getGameFrame().getGamePanel().updateAge();
				state.getGameFrame().getGamePanel().flipRotation();
			}
		}
		Scanner c = new Scanner(System.in);
		String xing = c.nextLine();
		Player[] arr = state.getBoard().getPlayers();
		ArrayList<Integer>[] arAl = new ArrayList[3]; 

		for (int i = 0; i < arr.length; i++)
		{
			arAl[i] = arr[i].calcScore(state.getBoard().getPlayers(), i);
		}
		
		state.getGameFrame().getGamePanel().endAll(arAl);
	}
}
