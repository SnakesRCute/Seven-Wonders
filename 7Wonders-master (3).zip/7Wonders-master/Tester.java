import java.io.*;
import java.util.*;
import static java.lang.System.*;

public class Tester {
	public static void main(String[]args) throws IOException
	{
		Deck niggnogg = new Deck();
		ArrayList<Card> one = niggnogg.getAge1();
		ArrayList<Card> two = niggnogg.getAge2();
		ArrayList<Card> three = niggnogg.getAge3();
		for(Card x : one)
		{
			x.print();
			System.out.println();
		}
		System.out.println(one.size() + "******************************************************************************************");
		for(Card x : two)
		{
			x.print();
			System.out.println();
		}
		System.out.println(two.size() + "******************************************************************************************");
		for(Card x : three)
		{
			x.print();
			System.out.println();
		}
		System.out.println(three.size() + "******************************************************************************************");
	}

}