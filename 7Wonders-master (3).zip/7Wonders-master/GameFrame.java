import javax.swing.JFrame;

public class GameFrame extends JFrame
{
	GamePanel gamePanel;
	
	public GameFrame()
	{
		super("Seven Wonders");
		
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setLayout(null);
		setVisible(true);

		gamePanel = new GamePanel();
		gamePanel.setSize(1920, 1080);
		add(gamePanel);
	}
	
	public GamePanel getPanel()
	{
		return gamePanel;
	}
	
	public GamePanel getGamePanel()
	{
		return gamePanel;
	}
}
