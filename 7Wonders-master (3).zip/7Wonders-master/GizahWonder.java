import java.util.TreeMap;

public class GizahWonder extends Wonder{
	private int extraVP;
	public GizahWonder(int lvl, String mat, String named, String[] level1, String[] level2, String[] level3) {
		super(lvl, mat, named, level1, level2, level3);
		// TODO Auto-generated constructor stub
	}
	
	public int getExtraVP() {
		return extraVP;
	}
	public void setExtraVP(int extraVP) {
		this.extraVP = extraVP;
	}
}