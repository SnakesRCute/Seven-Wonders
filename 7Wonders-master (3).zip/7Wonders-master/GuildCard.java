import java.util.Arrays;

public class GuildCard extends Card{
	private String typeOfCard, typeEarned;
	private String[] direction;
	private int amt;
	public GuildCard(int ages, String typ, String names, String upgrades, String costs, int amount, String[] direct, String type, String earn) {
		super(ages, typ, names, upgrades, costs);
		setAmt(amount);
		setDirection(direct);
		setTypeOfCard(type);
		setTypeEarned(earn);
	}
	public int getAmt() {
		return amt;
	}
	public void setAmt(int amt) {
		this.amt = amt;
	}
	public String[] getDirection() {
		return direction;
	}
	public void setDirection(String[] direction) {
		this.direction = direction;
	}
	public String getTypeOfCard() {
		return typeOfCard;
	}
	public void setTypeOfCard(String typeOfCard) {
		this.typeOfCard = typeOfCard;
	}
	public String getTypeEarned() {
		return typeEarned;
	}
	public void setTypeEarned(String typeEarned) {
		this.typeEarned = typeEarned;
	}
	public void print()
	{
		super.print();
		System.out.print(", TYPE: " + getTypeOfCard() + ", EARNED: " + getTypeEarned() + ", DIRECTION: " + Arrays.toString(getDirection()) + ", AMOUNT: " + getAmt());
	}

}
