import java.util.TreeMap;

public class BabylonWonder extends Wonder {
	
private Card extraScience;
	public BabylonWonder(int lvl, String mat, String named, String[] level1, String[] level2, String[] level3) {
		super(lvl, mat, named, level1, level2, level3);
	}
	public void setExtraScience(Card ex) {
		extraScience = ex;
	}
	public Card getExtraScience()
	{
		return extraScience;
	}
}