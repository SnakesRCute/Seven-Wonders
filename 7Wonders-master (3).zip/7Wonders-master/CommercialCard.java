import java.util.Arrays;

public class CommercialCard extends Card
{
	private String[] directions, mats;
	private boolean choiceOrNot;
	private String money;
	
	public CommercialCard(int ages, String types, String names, String upgrades, String costs, String[] direction, String[] mat, int moneyAmt, boolean choice)
	{
		super(ages, types, names, upgrades, costs);
		directions = direction;
		mats = mat;
		money = moneyAmt + "";
		choiceOrNot = choice;
	}
	
	public String[] getDirections()
	{
		return directions;
	}
	
	public String[] getMats()
	{
		return mats;
	}
	
	public String getMoney()
	{
		return money;
	}
	
	public boolean isChoice()
	{
		return choiceOrNot;
	}
	public void print()
	{
		super.print();
		System.out.print(", DIRECTION: " + Arrays.toString(directions) + ", MATERIALS: " + Arrays.toString(mats) + ", MONEY: " + money);
	}
}