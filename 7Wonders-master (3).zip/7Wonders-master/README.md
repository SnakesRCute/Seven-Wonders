# 7Wonders
SLHS CS2 
Classic Seven Wonders game coded entirely in java. 

![alt text](file:///C:/Users/SLHSCS216/Downloads/circleyeah.PNG)
