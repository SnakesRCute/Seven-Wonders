import java.util.TreeMap;

public class Halikarnassus extends Wonder{
	private Card discardCard;
	public Halikarnassus(int lvl, String mat, String named, String bonuses, TreeMap<String, Integer> upgrade) {
		super(lvl, mat, named, bonuses, upgrade);
	}
	public Card getDiscardCard() {
		return discardCard;
	}
	public void setDiscardCard(Card discardCard) {
		this.discardCard = discardCard;
	}
}
