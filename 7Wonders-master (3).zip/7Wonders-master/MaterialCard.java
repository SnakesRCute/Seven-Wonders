import java.util.Arrays;

public class MaterialCard extends Card{
	
	private String[] materials;
	private boolean choiceOrNot;
	
	public MaterialCard(int ages, String types, String names, String upgrades, String costs, String[] mats, boolean choice) 
	{
		super(ages, types, names, upgrades, costs);
		materials = mats;
		choiceOrNot = choice;
	}
	public String[] getMaterial()
	{
		return materials;
	}
	public boolean isChoice()
	{
		return choiceOrNot;
	}
	public void print()
	{
		super.print();
		System.out.print(", MATERIALS: " + Arrays.toString(materials) + ", CHOICE: " + choiceOrNot);
	}
}
