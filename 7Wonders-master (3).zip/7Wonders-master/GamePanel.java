import java.io.File;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.concurrent.TimeUnit;
import java.util.TreeMap;

public class GamePanel extends JPanel
{
	private BufferedImage background, rotation, redX;
	private ArrayList<BufferedImage> players, currentPlrOpt, playerStats;
	private int x, y, age, rot, choice, turnCurr, turnNext, turnPrev;
	private ArrayList<Card> currentOpt;
	private boolean clockWise, end, mainThing, leftSide, rightSide, leftBig, rightBig;
	private TreeMap<Integer, Card> choiceAndCard;
	private TreeMap<Integer, Integer> playerChoosing;
	private TreeMap<String, Integer> playerCards;
	private TreeMap<String, ArrayList<BufferedImage>> theirCards;
	private TreeMap<Integer, Integer> wonderRedX;
	private Player[] currPlayer;
	private ArrayList<Integer>[] arAl;
	
	public GamePanel()
	{
		super();
		arAl = new ArrayList[3];
		mainThing = false;
		leftSide = false;
		leftBig = false;
		rightBig = false;
		rightSide = false;
		currPlayer = new Player[3];
		theirCards = new TreeMap<String, ArrayList<BufferedImage>>();
		playerCards = new TreeMap<String, Integer>();
		choice = 0;
		turnCurr = 0; turnNext = 0; turnPrev = 0;
		wonderRedX = new TreeMap<Integer, Integer>();
		end = false;
		
		for (int posi = 0; posi < 3; posi++)
			wonderRedX.put(posi, 0);
		
		playerCards.put("Civilian", 0);
		playerCards.put("Commerce/Trade", 0);
		playerCards.put("Guild", 0);
		playerCards.put("Military", 0);
		playerCards.put("Resource", 0);
		playerCards.put("Science", 0);
		resetTheirCards();
		rot = 0;
		resetPlayerChoosing();
		choiceAndCard = new TreeMap<Integer, Card>();
		clockWise = true;
		age = 1;
		currentOpt = new ArrayList<Card>();
		players = new ArrayList<BufferedImage>();
		currentPlrOpt = new ArrayList<BufferedImage>();
		playerStats = new ArrayList<BufferedImage>();
		try
		{
			background = ImageIO.read(new File("Other/romeBackground.png"));
			rotation = ImageIO.read(new File("Other/rotation.png"));
			BufferedImage win = ImageIO.read(new File("Other/victory1.png"));
			BufferedImage loss = ImageIO.read(new File("Other/victoryminus1.png"));
			BufferedImage coin = ImageIO.read(new File("Other/coin1.png"));
			playerStats.add(win);
			playerStats.add(loss);
			playerStats.add(coin);
			redX = ImageIO.read(new File("Other/redX.png"));
			redX = resize(redX, 50, 50);
		}
		catch(Exception e)
		{
			System.out.println("error");
		}
		addMouseListener(new MouseAdapter()
		{
			public void mousePressed(MouseEvent e)
			{
				x = e.getX();
				y = e.getY();
			}
		});
	}
	
	public void resetTheirCards()
	{
		theirCards.put("Civilian", new ArrayList<BufferedImage>());
		theirCards.put("Commerce/Trade", new ArrayList<BufferedImage>());
		theirCards.put("Guild", new ArrayList<BufferedImage>());
		theirCards.put("Military", new ArrayList<BufferedImage>());
		theirCards.put("Resource", new ArrayList<BufferedImage>());
		theirCards.put("Science", new ArrayList<BufferedImage>());
	}
	
	public void addThisPlayersCards(Player p)
	{
		playerCards.put("Civilian", 0);
		playerCards.put("Commerce/Trade", 0);
		playerCards.put("Guild", 0);
		playerCards.put("Military", 0);
		playerCards.put("Resource", 0);
		playerCards.put("Science", 0);
		
		if (p.getHand().get("Civilian") != null)
			playerCards.put("Civilian", p.getHand().get("Civilian").size());
		if (p.getHand().get("Commerce/Trade") != null)
			playerCards.put("Commerce/Trade", p.getHand().get("Commerce/Trade").size());
		if (p.getHand().get("Guild") != null)
			playerCards.put("Guild", p.getHand().get("Guild").size());
		if (p.getHand().get("Military") != null)
			playerCards.put("Military", p.getHand().get("Military").size());
		if (p.getHand().get("Resource") != null)
			playerCards.put("Resource", p.getHand().get("Resource").size());
		if (p.getHand().get("Science") != null)
			playerCards.put("Science", p.getHand().get("Science").size());
	}
	
	public void resetPlayerChoosing()
	{
		playerChoosing = new TreeMap<Integer, Integer>();
		for (int posi = 0; posi < 7; posi++)
		{
			playerChoosing.put(posi, 0);
		}
	}
	
	public ArrayList<Card> getCurrentOptions()
	{
		return currentOpt;
	}
	
	public TreeMap<Integer, Card> getAction()
	{
		return choiceAndCard;
	}
	
	public void setAllSize()
	{
		rotation = resize(rotation, (getWidth() - players.get(1).getWidth() * 2) / 4, (getWidth() - players.get(1).getWidth() * 2) / 4);
		playerStats.set(0,resize(playerStats.get(0), players.get(0).getWidth() / 3 / 5, players.get(0).getHeight() / 5));
		playerStats.set(1,resize(playerStats.get(1), players.get(0).getWidth() / 3 / 5, players.get(0).getHeight() / 5));
		playerStats.set(2,resize(playerStats.get(2), players.get(0).getWidth() / 3 / 5, players.get(0).getHeight() / 5));
	}
	
	public TreeMap<Integer, Card> makeAction(Player[] p, int turn)
	{
		Card c = new Card();
		choiceAndCard = new TreeMap<Integer, Card>();
		while (true)
		{
			while (x == 0 && y == 0)
			{
				try {
					TimeUnit.MICROSECONDS.sleep(1000);
				}
				catch(Exception e) {
					System.out.println("error");
				}
			}
			int width = currentPlrOpt.get(0).getWidth();
			int height = currentPlrOpt.get(0).getHeight();
			int start = players.get(1).getWidth();
			if (x > start && x < start + width && y < height && currentOpt.size() >= 1)
			{
				for (int posi : playerChoosing.keySet())
					if (posi == 0)
						playerChoosing.put(0, playerChoosing.get(0) + 1);
					else
						playerChoosing.put(posi, 0);
				c = currentOpt.get(0);
			}
			else if (x > start + width && x < start + width * 2 && y < height && currentOpt.size() >= 2)
			{
				for (int posi : playerChoosing.keySet())
					if (posi == 1)
						playerChoosing.put(1, playerChoosing.get(1) + 1);
					else
						playerChoosing.put(posi, 0);
				c = currentOpt.get(1);
			}
			else if (x > start + (width * 2) && x < start + (width * 3) && y < height && currentOpt.size() >= 3)
			{
				for (int posi : playerChoosing.keySet())
				if (posi == 2)
					playerChoosing.put(2, playerChoosing.get(2) + 1);
				else
					playerChoosing.put(posi, 0);
					
				c = currentOpt.get(2);
			}
			else if (x > start + (width * 3) && x < start + (width * 4) && y < height && currentOpt.size() >= 4)
			{
				for (int posi : playerChoosing.keySet())
					if (posi == 3)
						playerChoosing.put(3, playerChoosing.get(3) + 1);
					else
						playerChoosing.put(posi, 0);
				c = currentOpt.get(3);
			}
			else if (x > start && x < start + width && y > height && y < height * 2 && currentOpt.size() >= 5)
			{
				for (int posi : playerChoosing.keySet())
					if (posi == 4)
						playerChoosing.put(4, playerChoosing.get(4) + 1);
					else
						playerChoosing.put(posi, 0);
				c = currentOpt.get(4);
			}
			else if (x > start + width && x < start + (width * 2) && y > height && y < height * 2 && currentOpt.size() >= 6)
			{
				for (int posi : playerChoosing.keySet())
					if (posi == 5)
						playerChoosing.put(5, playerChoosing.get(5) + 1);
					else
						playerChoosing.put(posi, 0);
					c = currentOpt.get(5);
			}
			else if (x > start + (width * 2) && x < start + (width * 3) && y > height && y < height * 2 && currentOpt.size() == 7)
			{
				for (int posi : playerChoosing.keySet())
					if (posi == 6)
						playerChoosing.put(6, playerChoosing.get(6) + 1);
					else
						playerChoosing.put(posi, 0);
				c = currentOpt.get(6);
			}
			else if (x > 0 && x < currentPlrOpt.get(0).getWidth() * 6 && y > getHeight() - currentPlrOpt.get(0).getHeight())
			{
				pullUpMain(x, y, p[turnCurr]);
			}
			else if (x > 0 && x < currentPlrOpt.get(0).getWidth() && y > players.get(1).getHeight() && y < players.get(1).getHeight() + currentPlrOpt.get(0).getHeight())
			{
				if (clockWise)
					pullUpLeft(p[turnPrev]);
				else
					pullUpLeft(p[turnNext]);
			}
			else if (x > getWidth() - currentPlrOpt.get(0).getWidth() && x < getWidth() && y > players.get(1).getHeight() && y < players.get(1).getHeight() + currentPlrOpt.get(0).getHeight())
			{
				if (clockWise)
					pullUpRight(x, y, p[turnNext]);
				else
					pullUpRight(x, y, p[turnPrev]);
			}
			
			if (x != 0 && y != 0)
				repaint();
			x = 0; y = 0;
			if (playerChoosing.containsValue(2))
				break;
		}
		repaint();
		choiceAndCard.put(chooseAction(), c);
		resetPlayerChoosing();
		x = 0; y = 0;
		return choiceAndCard;
	}
	
	public void updateWonderUpgrade()
	{
		wonderRedX.put(0, wonderRedX.get(0) + 1);
	}
	
	public void setOptions(ArrayList<Card> temp, int current, Player[] p, int t)
	{
		currPlayer = p;
		turnCurr = t;
		
		if (clockWise)
		{
			if (turnCurr == 0)
			{
				turnNext = 1;
				turnPrev = 2;
			}
			else if (turnCurr == 1)
			{
				turnNext = 2;
				turnPrev = 0;
			}
			else
			{
				turnNext = 0;
				turnPrev = 1;
			}
		}
		else
		{
			if (turnCurr == 0)
			{
				turnNext = 2;
				turnPrev = 1;
			}
			else if (turnCurr == 1)
			{
				turnNext = 0;
				turnPrev = 2;
			}
			else
			{
				turnNext = 1;
				turnPrev = 0;
			}
		}
		
		currentOpt = new ArrayList<Card>();
		repaint();
		currentOpt = temp;
		currentPlrOpt = new ArrayList<BufferedImage>();
		
		for (int posi = 0; posi < currentOpt.size(); posi++)
		{
			try {
			BufferedImage img = ImageIO.read(new File("CardPNG/" + currentOpt.get(posi).getName() + ".png"));
			currentPlrOpt.add(img);
			}
			catch (Exception e) {
				System.out.println("error");
			}
		}
		repaint();	
	}
	public void flipRotation()
	{
		BufferedImage newImage = new BufferedImage(rotation.getWidth(), rotation.getHeight(), BufferedImage.TYPE_INT_ARGB);
		Graphics2D gg = newImage.createGraphics();
		gg.drawImage(rotation, rotation.getHeight(), 0, -rotation.getWidth(), rotation.getHeight(), null);
		gg.dispose();
		rotation = newImage;
		if (clockWise)
			clockWise = false;
		else
			clockWise = true;
		repaint();
	}
	
	public void rotatePlayers()
	{
		if (clockWise)
		{
			try {
				BufferedImage temp1 = ImageIO.read(new File("WonderPNG/" + currPlayer[turnCurr].getWonder().getName() + "A.png"));
				BufferedImage temp2 = ImageIO.read(new File("WonderPNG/" + currPlayer[turnNext].getWonder().getName() + "A.png"));
				BufferedImage temp3 = ImageIO.read(new File("WonderPNG/" + currPlayer[turnPrev].getWonder().getName() + "A.png"));
				players.set(0, temp2);
				players.set(1, temp3);
				players.set(2, temp1);
			}
			catch (Exception e) {
				System.out.println("error");
			}
			int tempRed1 = wonderRedX.get(0);
			int tempRed2 = wonderRedX.get(1);
			int tempRed3 = wonderRedX.get(2);
			wonderRedX.put(0, tempRed2);
			wonderRedX.put(1, tempRed3);
			wonderRedX.put(2, tempRed1);
			
		}
		else 
		{

			try {
				BufferedImage temp1 = ImageIO.read(new File("WonderPNG/" + currPlayer[turnCurr].getWonder().getName() + "A.png"));
				BufferedImage temp2 = ImageIO.read(new File("WonderPNG/" + currPlayer[turnNext].getWonder().getName() + "A.png"));
				BufferedImage temp3 = ImageIO.read(new File("WonderPNG/" + currPlayer[turnPrev].getWonder().getName() + "A.png"));
				players.set(0, temp2);
				players.set(1, temp1);
				players.set(2, temp3);
			}
			catch (Exception e) {
				System.out.println("error");
			}
			
			int tempRed1 = wonderRedX.get(0);
			int tempRed2 = wonderRedX.get(1);
			int tempRed3 = wonderRedX.get(2);
			wonderRedX.put(0, tempRed2);
			wonderRedX.put(1, tempRed1);
			wonderRedX.put(2, tempRed3);
		}
		repaint();
	}
	
	public void paint(Graphics g)
	{
		Graphics2D g2 = (Graphics2D) g;
		
		g.drawImage(background, 0, 0, null);
		
		if (players.size() == 3)
		{
			players.set(0, resize(players.get(0), getWidth() / 2, getHeight() / 4));
			players.set(1, resize(players.get(1), getWidth() / 6 * 2, getHeight() / 4));
			players.set(2, resize(players.get(2), getWidth() / 6 * 2, getHeight() / 4));
			
			g.drawImage(players.get(0), getWidth() / 2, getHeight() / 4 * 3, null);
			g.drawImage(players.get(1), getWidth() - players.get(1).getWidth(), 0, null);
			g.drawImage(players.get(2), 0, 0, null);
			
			Rectangle rect = new Rectangle(players.get(1).getWidth(), 0, getWidth() - players.get(1).getWidth() * 2, players.get(1).getHeight() / 2 * 3);
			g2.setColor(Color.WHITE);
			g2.fill(rect);
			int tempHeight = (int) rect.getHeight();
			if (rot == 0)
			{
				setAllSize();
				rot++;
			}
			g.drawImage(rotation, players.get(1).getWidth() + rect.width - rotation.getWidth(), (int) rect.getHeight() - rotation.getHeight(), null);
			
			g.setFont(new Font("Times New Roman", Font.BOLD, 50));
			g.setColor(Color.BLACK);
			g.drawString("Age:  " + age, players.get(1).getWidth() + (int) rect.getWidth() - rotation.getWidth(), (int) rect.getHeight() - rotation.getHeight() - 7);
			
			if (currentPlrOpt.size() > 0)
			{
				int xx = 0; int yy = 0;
				for (int posi = 0; posi < currentPlrOpt.size(); posi++)
				{
					currentPlrOpt.set(posi, resize(currentPlrOpt.get(posi), (int) rect.getWidth() / 4, (int) rect.getHeight() / 2));
					
					try {
						g.drawImage(currentPlrOpt.get(posi), players.get(1).getWidth() + xx, yy, null);
					
						xx += currentPlrOpt.get(posi).getWidth();
						if (xx == currentPlrOpt.get(posi).getWidth() * 4)
						{
							xx = 0;
							yy = currentPlrOpt.get(posi).getHeight();
						}
					}
					catch (Exception e)
					{
						System.out.println("error");
					}
				}
			}
			
			if (currentPlrOpt.size() > 0)
			{
				g2.setStroke(new java.awt.BasicStroke(5));
				Rectangle boxOption = new Rectangle(0, getHeight() - currentPlrOpt.get(0).getHeight(), currentPlrOpt.get(0).getWidth() * 6, currentPlrOpt.get(0).getHeight());
				g2.setColor(Color.DARK_GRAY);
				g2.fill(boxOption);
				g2.setColor(Color.RED);
				g2.setStroke(new java.awt.BasicStroke(5));
				boxOption = new Rectangle(0, getHeight() - currentPlrOpt.get(0).getHeight(), currentPlrOpt.get(0).getWidth(), currentPlrOpt.get(0).getHeight());
				g2.draw(boxOption);
				boxOption = new Rectangle(currentPlrOpt.get(0).getWidth(), getHeight() - currentPlrOpt.get(0).getHeight(), currentPlrOpt.get(0).getWidth(), currentPlrOpt.get(0).getHeight());
				g2.draw(boxOption);
				boxOption = new Rectangle(currentPlrOpt.get(0).getWidth() * 2, getHeight() - currentPlrOpt.get(0).getHeight(), currentPlrOpt.get(0).getWidth(), currentPlrOpt.get(0).getHeight());
				g2.draw(boxOption);
				boxOption = new Rectangle(currentPlrOpt.get(0).getWidth() * 3, getHeight() - currentPlrOpt.get(0).getHeight(), currentPlrOpt.get(0).getWidth(), currentPlrOpt.get(0).getHeight());
				g2.draw(boxOption);
				boxOption = new Rectangle(currentPlrOpt.get(0).getWidth() * 4, getHeight() - currentPlrOpt.get(0).getHeight(), currentPlrOpt.get(0).getWidth(), currentPlrOpt.get(0).getHeight());
				g2.draw(boxOption);
				boxOption = new Rectangle(currentPlrOpt.get(0).getWidth() * 5, getHeight() - currentPlrOpt.get(0).getHeight(), currentPlrOpt.get(0).getWidth(), currentPlrOpt.get(0).getHeight());
				g2.draw(boxOption);
			
				g2.setColor(Color.DARK_GRAY);
				boxOption = new Rectangle(0, players.get(1).getHeight(), currentPlrOpt.get(0).getWidth(), currentPlrOpt.get(0).getHeight());
				g2.fill(boxOption);
				boxOption = new Rectangle(getWidth() - currentPlrOpt.get(0).getWidth(), players.get(1).getHeight(), currentPlrOpt.get(0).getWidth(), currentPlrOpt.get(0).getHeight());
				g2.fill(boxOption);
				g2.setColor(Color.RED);
				boxOption = new Rectangle(0, players.get(1).getHeight(), currentPlrOpt.get(0).getWidth(), currentPlrOpt.get(0).getHeight());
				g2.draw(boxOption);
				boxOption = new Rectangle(getWidth() - currentPlrOpt.get(0).getWidth(), players.get(1).getHeight(), currentPlrOpt.get(0).getWidth(), currentPlrOpt.get(0).getHeight());
				g2.draw(boxOption);
			
			
				g2.setColor(Color.BLACK);
				g2.setFont(new Font("Times New Roman", Font.BOLD, 30));
				g2.drawString("You have " + playerCards.get("Civilian"), 5, getHeight() - currentPlrOpt.get(0).getHeight() + 30);
				g2.drawString("You have " + playerCards.get("Commerce/Trade"), currentPlrOpt.get(0).getWidth() + 5, getHeight() - currentPlrOpt.get(0).getHeight() + 30);
				g2.drawString("You have " + playerCards.get("Guild"), currentPlrOpt.get(0).getWidth() * 2 + 5, getHeight() - currentPlrOpt.get(0).getHeight() + 30);
				g2.drawString("You have " + playerCards.get("Military"), currentPlrOpt.get(0).getWidth() * 3 + 5, getHeight() - currentPlrOpt.get(0).getHeight() + 30);
				g2.drawString("You have " + playerCards.get("Resource"), currentPlrOpt.get(0).getWidth() * 4 + 5, getHeight() - currentPlrOpt.get(0).getHeight() + 30);
				g2.drawString("You have " + playerCards.get("Science"), currentPlrOpt.get(0).getWidth() * 5 + 5, getHeight() - currentPlrOpt.get(0).getHeight() + 30);
				g2.drawString("Click to see", 5, players.get(1).getHeight() + 25);
				g2.drawString("Click to see", getWidth() - currentPlrOpt.get(0).getWidth() + 5, players.get(1).getHeight() + 25);
				g2.setFont(new Font("Times New Roman", Font.BOLD, 25));
				g2.drawString("player's cards", 5, players.get(1).getHeight() + 55);
				g2.drawString("player's cards", getWidth() - currentPlrOpt.get(0).getWidth() + 5, players.get(1).getHeight() + 55);
				g2.setFont(new Font("Times New Roman", Font.BOLD, 30));
			
				g2.drawString("Civilian", 5, getHeight() - currentPlrOpt.get(0).getHeight() + 55);
				g2.setFont(new Font("Times New Roman", Font.BOLD, 20));
				g2.drawString("Commerce/Trade", currentPlrOpt.get(0).getWidth() + 5, getHeight() - currentPlrOpt.get(0).getHeight() + 55);
				g2.setFont(new Font("Times New Roman", Font.BOLD, 30));
				g2.drawString("Guild", currentPlrOpt.get(0).getWidth() * 2 + 5, getHeight() - currentPlrOpt.get(0).getHeight() + 55);
				g2.drawString("Military", currentPlrOpt.get(0).getWidth() * 3 + 5, getHeight() - currentPlrOpt.get(0).getHeight() + 55);
				g2.drawString("Resource", currentPlrOpt.get(0).getWidth() * 4 + 5, getHeight() - currentPlrOpt.get(0).getHeight() + 55);
				g2.drawString("Science", currentPlrOpt.get(0).getWidth() * 5 + 5, getHeight() - currentPlrOpt.get(0).getHeight() + 55);
			
				g2.drawString("Click to see", 5, getHeight() - currentPlrOpt.get(0).getHeight() + 90);
				g2.drawString("Click to see", currentPlrOpt.get(0).getWidth() + 5, getHeight() - currentPlrOpt.get(0).getHeight() + 90);
				g2.drawString("Click to see", currentPlrOpt.get(0).getWidth() * 2 + 5, getHeight() - currentPlrOpt.get(0).getHeight() + 90);
				g2.drawString("Click to see", currentPlrOpt.get(0).getWidth() * 3 + 5, getHeight() - currentPlrOpt.get(0).getHeight() + 90);
				g2.drawString("Click to see", currentPlrOpt.get(0).getWidth() * 4 + 5, getHeight() - currentPlrOpt.get(0).getHeight() + 90);
				g2.drawString("Click to see", currentPlrOpt.get(0).getWidth() * 5 + 5, getHeight() - currentPlrOpt.get(0).getHeight() + 90);
			
				g2.setFont(new Font("Times New Roman", Font.BOLD, 23));
				g2.drawString("Civilian cards", 5, getHeight() - currentPlrOpt.get(0).getHeight() + 115);
				g2.setFont(new Font("Times New Roman", Font.BOLD, 20));
				g2.drawString("Commerce/Trade", currentPlrOpt.get(0).getWidth() + 5, getHeight() - currentPlrOpt.get(0).getHeight() + 115);
				g2.setFont(new Font("Times New Roman", Font.BOLD, 23));
				g2.drawString("cards", currentPlrOpt.get(0).getWidth() + 5, getHeight() - currentPlrOpt.get(0).getHeight() + 140);
				g2.drawString("Guild cards", currentPlrOpt.get(0).getWidth() * 2 + 5, getHeight() - currentPlrOpt.get(0).getHeight() + 115);
				g2.drawString("Military cards", currentPlrOpt.get(0).getWidth() * 3 + 5, getHeight() - currentPlrOpt.get(0).getHeight() + 115);
				g2.drawString("Resource cards", currentPlrOpt.get(0).getWidth() * 4 + 5, getHeight() - currentPlrOpt.get(0).getHeight() + 115);
				g2.drawString("Science cards", currentPlrOpt.get(0).getWidth() * 5 + 5, getHeight() - currentPlrOpt.get(0).getHeight() + 115);
			}
			
			g2.setColor(Color.GRAY);
			int tempX = (int) rect.getWidth();
			int tempy = (int) rect.getHeight();
			
			rect = new Rectangle(getWidth() - players.get(0).getWidth(), getHeight() - players.get(0).getHeight() - players.get(0).getHeight() / 5, players.get(0).getWidth() / 3,  players.get(0).getHeight() / 5);
			g2.fill(rect);
			rect = new Rectangle(getWidth() - (getWidth() - players.get(1).getWidth() / 2) - (int) rect.getWidth() / 5, players.get(1).getHeight(), players.get(0).getWidth() / 3,  players.get(0).getHeight() / 5);
			g2.fill(rect);
			rect = new Rectangle(players.get(1).getWidth() + (getWidth() - players.get(1).getWidth() * 2) + (int) rect.getWidth() / 5, players.get(1).getHeight(), players.get(0).getWidth() / 3,  players.get(0).getHeight() / 5);
			g2.fill(rect);
			
			Rectangle rectTemp = new Rectangle(getWidth() - players.get(0).getWidth() + (int) rect.getWidth(), getHeight() - players.get(0).getHeight() - players.get(0).getHeight() / 5, players.get(0).getWidth() / 3 / 5,  players.get(0).getHeight() / 5);
			g2.fill(rectTemp);
			rectTemp = new Rectangle(getWidth() - (getWidth() - players.get(1).getWidth() / 2) - (int) rect.getWidth() / 5 + (int) rect.getWidth(), players.get(1).getHeight(), players.get(0).getWidth() / 3 / 5,  players.get(0).getHeight() / 5);
			g2.fill(rectTemp);
			rectTemp = new Rectangle(players.get(1).getWidth() + (getWidth() - players.get(1).getWidth() * 2), players.get(1).getHeight(), players.get(0).getWidth() / 3 / 5,  players.get(0).getHeight() / 5);
			g2.fill(rectTemp);
			
			for (int posi = 0; posi < players.size(); posi++)
			{
				g.setColor(Color.BLACK);
				g.setFont(new Font("Times New Roman", Font.BOLD, 65));
				
				if (clockWise)
				{
					g.drawImage(playerStats.get(0), getWidth() - players.get(0).getWidth(), getHeight() - players.get(0).getHeight() - (int) rect.getHeight(), null);
					g.drawString(Integer.toString(currPlayer[turnCurr].getWinNum()), getWidth() - players.get(0).getWidth() + playerStats.get(0).getWidth(), getHeight() - players.get(0).getHeight() - 5);
					g.drawImage(playerStats.get(1), getWidth() - players.get(0).getWidth() + (int) rect.getWidth() / 5 * 2, getHeight() - players.get(0).getHeight() - (int) rect.getHeight(), null);
					g.drawString(Integer.toString(currPlayer[turnCurr].getLosses()), getWidth() - players.get(0).getWidth() + playerStats.get(0).getWidth() * 3, getHeight() - players.get(0).getHeight() - 5);
					g.drawImage(playerStats.get(2), getWidth() - players.get(0).getWidth() + (int) rect.getWidth() / 5 * 4, getHeight() - players.get(0).getHeight() - (int) rect.getHeight(), null);
					g.drawString(Integer.toString(currPlayer[turnCurr].getCoins()), getWidth() - players.get(0).getWidth() + playerStats.get(0).getWidth() * 5, getHeight() - players.get(0).getHeight() - 5);

					g.drawImage(playerStats.get(0), players.get(1).getWidth() + (getWidth() - players.get(1).getWidth() * 2), players.get(1).getHeight(), null);
					g.drawString(Integer.toString(currPlayer[turnNext].getWinNum()), players.get(1).getWidth() + (getWidth() - players.get(1).getWidth() * 2) + playerStats.get(0).getWidth(), players.get(1).getHeight() + playerStats.get(0).getHeight() - 5);
					g.drawImage(playerStats.get(1), players.get(1).getWidth() + (getWidth() - players.get(1).getWidth() * 2) + playerStats.get(0).getWidth() * 2, players.get(1).getHeight(), null);
					g.drawString(Integer.toString(currPlayer[turnNext].getLosses()), players.get(1).getWidth() + (getWidth() - players.get(1).getWidth() * 2) + playerStats.get(0).getWidth() * 3, players.get(1).getHeight() + playerStats.get(0).getHeight() - 5);
					g.drawImage(playerStats.get(2), players.get(1).getWidth() + (getWidth() - players.get(1).getWidth() * 2) + playerStats.get(0).getWidth() * 4, players.get(1).getHeight(), null);
					g.drawString(Integer.toString(currPlayer[turnNext].getCoins()), players.get(1).getWidth() + (getWidth() - players.get(1).getWidth() * 2) + playerStats.get(0).getWidth() * 5, players.get(1).getHeight() + playerStats.get(0).getHeight() - 5);
				
					g.drawImage(playerStats.get(0), getWidth() - (getWidth() - players.get(1).getWidth() / 2) - (int) rect.getWidth() / 5, players.get(1).getHeight(), null);
					g.drawString(Integer.toString(currPlayer[turnPrev].getWinNum()), getWidth() - (getWidth() - players.get(1).getWidth() / 2) - (int) rect.getWidth() / 5 + playerStats.get(0).getWidth(), players.get(1).getHeight() + playerStats.get(0).getHeight() - 5);
					g.drawImage(playerStats.get(1), (getWidth() - (getWidth() - players.get(1).getWidth() / 2)) + playerStats.get(0).getWidth() * 2 - (int) rect.getWidth() / 5, players.get(1).getHeight(), null);
					g.drawString(Integer.toString(currPlayer[turnPrev].getLosses()), getWidth() - (getWidth() - players.get(1).getWidth() / 2) - (int) rect.getWidth() / 5 + playerStats.get(0).getWidth() * 3, players.get(1).getHeight() + playerStats.get(0).getHeight() - 5);
					g.drawImage(playerStats.get(2), (getWidth() - (getWidth() - players.get(1).getWidth() / 2)) + playerStats.get(0).getWidth() * 4 - (int) rect.getWidth() / 5, players.get(1).getHeight(), null);
					g.drawString(Integer.toString(currPlayer[turnPrev].getCoins()), getWidth() - (getWidth() - players.get(1).getWidth() / 2) - (int) rect.getWidth() / 5 + playerStats.get(0).getWidth() * 5, players.get(1).getHeight() + playerStats.get(0).getHeight() - 5);
				}
				else
				{
					g.drawImage(playerStats.get(0), getWidth() - players.get(0).getWidth(), getHeight() - players.get(0).getHeight() - (int) rect.getHeight(), null);
					g.drawString(Integer.toString(currPlayer[turnCurr].getWinNum()), getWidth() - players.get(0).getWidth() + playerStats.get(0).getWidth(), getHeight() - players.get(0).getHeight() - 5);
					g.drawImage(playerStats.get(1), getWidth() - players.get(0).getWidth() + (int) rect.getWidth() / 5 * 2, getHeight() - players.get(0).getHeight() - (int) rect.getHeight(), null);
					g.drawString(Integer.toString(currPlayer[turnCurr].getLosses()), getWidth() - players.get(0).getWidth() + playerStats.get(0).getWidth() * 3, getHeight() - players.get(0).getHeight() - 5);
					g.drawImage(playerStats.get(2), getWidth() - players.get(0).getWidth() + (int) rect.getWidth() / 5 * 4, getHeight() - players.get(0).getHeight() - (int) rect.getHeight(), null);
					g.drawString(Integer.toString(currPlayer[turnCurr].getCoins()), getWidth() - players.get(0).getWidth() + playerStats.get(0).getWidth() * 5, getHeight() - players.get(0).getHeight() - 5);

					g.drawImage(playerStats.get(0), players.get(1).getWidth() + (getWidth() - players.get(1).getWidth() * 2), players.get(1).getHeight(), null);
					g.drawString(Integer.toString(currPlayer[turnPrev].getWinNum()), players.get(1).getWidth() + (getWidth() - players.get(1).getWidth() * 2) + playerStats.get(0).getWidth(), players.get(1).getHeight() + playerStats.get(0).getHeight() - 5);
					g.drawImage(playerStats.get(1), players.get(1).getWidth() + (getWidth() - players.get(1).getWidth() * 2) + playerStats.get(0).getWidth() * 2, players.get(1).getHeight(), null);
					g.drawString(Integer.toString(currPlayer[turnPrev].getLosses()), players.get(1).getWidth() + (getWidth() - players.get(1).getWidth() * 2) + playerStats.get(0).getWidth() * 3, players.get(1).getHeight() + playerStats.get(0).getHeight() - 5);
					g.drawImage(playerStats.get(2), players.get(1).getWidth() + (getWidth() - players.get(1).getWidth() * 2) + playerStats.get(0).getWidth() * 4, players.get(1).getHeight(), null);
					g.drawString(Integer.toString(currPlayer[turnPrev].getCoins()), players.get(1).getWidth() + (getWidth() - players.get(1).getWidth() * 2) + playerStats.get(0).getWidth() * 5, players.get(1).getHeight() + playerStats.get(0).getHeight() - 5);
				
					g.drawImage(playerStats.get(0), getWidth() - (getWidth() - players.get(1).getWidth() / 2) - (int) rect.getWidth() / 5, players.get(1).getHeight(), null);
					g.drawString(Integer.toString(currPlayer[turnNext].getWinNum()), getWidth() - (getWidth() - players.get(1).getWidth() / 2) - (int) rect.getWidth() / 5 + playerStats.get(0).getWidth(), players.get(1).getHeight() + playerStats.get(0).getHeight() - 5);
					g.drawImage(playerStats.get(1), (getWidth() - (getWidth() - players.get(1).getWidth() / 2)) + playerStats.get(0).getWidth() * 2 - (int) rect.getWidth() / 5, players.get(1).getHeight(), null);
					g.drawString(Integer.toString(currPlayer[turnNext].getLosses()), getWidth() - (getWidth() - players.get(1).getWidth() / 2) - (int) rect.getWidth() / 5 + playerStats.get(0).getWidth() * 3, players.get(1).getHeight() + playerStats.get(0).getHeight() - 5);
					g.drawImage(playerStats.get(2), (getWidth() - (getWidth() - players.get(1).getWidth() / 2)) + playerStats.get(0).getWidth() * 4 - (int) rect.getWidth() / 5, players.get(1).getHeight(), null);
					g.drawString(Integer.toString(currPlayer[turnNext].getCoins()), getWidth() - (getWidth() - players.get(1).getWidth() / 2) - (int) rect.getWidth() / 5 + playerStats.get(0).getWidth() * 5, players.get(1).getHeight() + playerStats.get(0).getHeight() - 5);
				}
			}
			
			g2.setStroke(new java.awt.BasicStroke(2));
			rect = new Rectangle(players.get(1).getWidth(), tempy, tempX, players.get(1).getHeight() / 4);
			g2.setColor(Color.BLACK);
			g2.fill(rect);
			int tempWidth = (int) rect.getWidth();

			g2.setColor(Color.GRAY);
			rect = new Rectangle(tempWidth, tempHeight, tempWidth / 4, players.get(1).getHeight() / 4);
			g2.fill(rect);
			g2.setColor(Color.RED);
			g2.draw(rect);
			g2.setColor(Color.GRAY);
			rect = new Rectangle(tempWidth + (tempWidth / 2) - (int) rect.getWidth() / 2, tempHeight, tempWidth / 4, players.get(1).getHeight() / 4);
			g2.fill(rect);
			g2.setColor(Color.RED);
			g2.draw(rect);
			g2.setColor(Color.GRAY);
			rect = new Rectangle(tempWidth * 2 - (int) rect.getWidth(), tempHeight, tempWidth / 4, players.get(1).getHeight() / 4);
			g2.fill(rect);
			g2.setColor(Color.RED);
			g2.draw(rect);
			
			g.setFont(new Font("Times New Roman", Font.BOLD, 31));
			g.drawString("Build Stage", tempWidth, tempHeight + (int) rect.getHeight() / 3 * 2);	
			g.setFont(new Font("Times New Roman", Font.BOLD, 35));
			g.drawString("Play", tempWidth + (tempWidth / 2) - (int) rect.getWidth() / 5, tempHeight + (int) rect.getHeight() / 3 * 2);
			g.setFont(new Font("Times New Roman", Font.BOLD, 35));
			g.drawString("Discard", tempWidth * 2 - (int) rect.getWidth() + (int) rect.getWidth() / 6, tempHeight + (int) rect.getHeight() / 3 * 2);
			
			g2.setColor(Color.YELLOW);
			g2.setStroke(new java.awt.BasicStroke(4));
			if (playerChoosing.containsValue(1) || playerChoosing.containsValue(2))
			{
				for (int posi : playerChoosing.keySet())
				{
					if (posi == 0)
					{
						if (playerChoosing.get(posi) == 1)
						{
							rect = new Rectangle(players.get(1).getWidth(), 0, currentPlrOpt.get(posi).getWidth(), currentPlrOpt.get(posi).getHeight());
							g2.draw(rect);
						}
						else if (playerChoosing.get(posi) == 2)
						{
							g2.setColor(Color.RED);
							rect = new Rectangle(players.get(1).getWidth(), 0, currentPlrOpt.get(posi).getWidth(), currentPlrOpt.get(posi).getHeight());
							g2.draw(rect);
						}
					}
					else if (posi == 1)
					{
						if (playerChoosing.get(posi) == 1)
						{
							rect = new Rectangle(players.get(1).getWidth() + currentPlrOpt.get(posi).getWidth(), 0, currentPlrOpt.get(posi).getWidth(), currentPlrOpt.get(posi).getHeight());
							g2.draw(rect);
						}
						else if (playerChoosing.get(posi) == 2)
						{
							g2.setColor(Color.RED);
							rect = new Rectangle(players.get(1).getWidth() + currentPlrOpt.get(posi).getWidth(), 0, currentPlrOpt.get(posi).getWidth(), currentPlrOpt.get(posi).getHeight());
							g2.draw(rect);
						}
					}
					else if (posi == 2)
					{
						if (playerChoosing.get(posi) == 1)
						{
							rect = new Rectangle(players.get(1).getWidth() + currentPlrOpt.get(posi).getWidth() * 2, 0, currentPlrOpt.get(posi).getWidth(), currentPlrOpt.get(posi).getHeight());
							g2.draw(rect);
						}
						else if (playerChoosing.get(posi) == 2)
						{
							g2.setColor(Color.RED);
							rect = new Rectangle(players.get(1).getWidth() + currentPlrOpt.get(posi).getWidth() * 2, 0, currentPlrOpt.get(posi).getWidth(), currentPlrOpt.get(posi).getHeight());
							g2.draw(rect);
						}
					}
					else if (posi == 3)
					{
						if (playerChoosing.get(posi) == 1)
						{
							rect = new Rectangle(players.get(1).getWidth() + currentPlrOpt.get(posi).getWidth() * 3, 0, currentPlrOpt.get(posi).getWidth(), currentPlrOpt.get(posi).getHeight());
							g2.draw(rect);
						}
						else if (playerChoosing.get(posi) == 2)
						{
							g2.setColor(Color.RED);
							rect = new Rectangle(players.get(1).getWidth() + currentPlrOpt.get(posi).getWidth() * 3, 0, currentPlrOpt.get(posi).getWidth(), currentPlrOpt.get(posi).getHeight());
							g2.draw(rect);
						}
					}
					else if (posi == 4)
					{
						if (playerChoosing.get(posi) == 1)
						{
							rect = new Rectangle(players.get(1).getWidth(), currentPlrOpt.get(posi).getHeight(), currentPlrOpt.get(posi).getWidth(), currentPlrOpt.get(posi).getHeight());
							g2.draw(rect);
						}	
						else if (playerChoosing.get(posi) == 2)
						{
							g2.setColor(Color.RED);
							rect = new Rectangle(players.get(1).getWidth(), currentPlrOpt.get(posi).getHeight(), currentPlrOpt.get(posi).getWidth(), currentPlrOpt.get(posi).getHeight());
							g2.draw(rect);
						}
					}
					else if (posi == 5)
					{
						if (playerChoosing.get(posi) == 1)
						{
							rect = new Rectangle(players.get(1).getWidth() + currentPlrOpt.get(posi).getWidth(), currentPlrOpt.get(posi).getHeight(), currentPlrOpt.get(posi).getWidth(), currentPlrOpt.get(posi).getHeight());
							g2.draw(rect);
						}	
						else if (playerChoosing.get(posi) == 2)
						{
							g2.setColor(Color.RED);
							rect = new Rectangle(players.get(1).getWidth() + currentPlrOpt.get(posi).getWidth(), currentPlrOpt.get(posi).getHeight(), currentPlrOpt.get(posi).getWidth(), currentPlrOpt.get(posi).getHeight());
							g2.draw(rect);
						}
					}
					else if (posi == 6)
					{
						if (playerChoosing.get(posi) == 1)
						{
							rect = new Rectangle(players.get(1).getWidth() + currentPlrOpt.get(posi).getWidth() * 2, currentPlrOpt.get(posi).getHeight(), currentPlrOpt.get(posi).getWidth(), currentPlrOpt.get(posi).getHeight());
							g2.draw(rect);
						}		
						else if (playerChoosing.get(posi) == 2)
						{
							g2.setColor(Color.RED);
							rect = new Rectangle(players.get(1).getWidth() + currentPlrOpt.get(posi).getWidth() * 2, currentPlrOpt.get(posi).getHeight(), currentPlrOpt.get(posi).getWidth(), currentPlrOpt.get(posi).getHeight());
							g2.draw(rect);
						}
					}
				}
			}
			for (int posi : wonderRedX.keySet())
			{
				int x1 = 160 * 7;
				int x2 = getWidth() - (180 * 3);
				int x3 = 120;					
				for (int pos = 0; pos < wonderRedX.get(posi); pos++)
				{
					if (posi == 0 && wonderRedX.get(posi) > 0)
					{
						try {
							g.drawImage(redX, x1, getHeight() - 50, null);
						}
						catch (Exception e) {
							System.out.println("error");
						}
						x1 += currentPlrOpt.get(0).getWidth();
					}
					else if (posi == 1)
					{
						try {
							g.drawImage(redX, x2, players.get(1).getHeight() - 50, null);
						}
						catch (Exception e) {
							System.out.println("error");
						}
						x2 += 180;
					}
					else if (posi == 2)
					{
						try {
							g.drawImage(redX, x3, players.get(1).getHeight() - 50, null);
						}
						catch (Exception e) {
							System.out.println("error");
						}
						x2 += currentPlrOpt.get(0).getWidth();
					}
				}
			}
			
			if (theirCards.size() > 0 && mainThing)
			{
				if (theirCards.get("Civilian").size() >= 0 && choice == 1)
				{
					g2.setColor(Color.GRAY);
					Rectangle grayBox = new Rectangle(0, getHeight() / 4, getWidth(), getHeight() / 2);
					g2.fill(grayBox);
					g.drawImage(redX, 0, getHeight() / 4, null );
					int xx = currentPlrOpt.get(0).getWidth(); int yy = getHeight() / 4;
					for (int posi = 0; posi < theirCards.get("Civilian").size(); posi++)
					{
						theirCards.get("Civilian").set(posi, resize(theirCards.get("Civilian").get(posi), theirCards.get("Civilian").get(posi).getWidth(), getHeight() / 4));
						g.drawImage(theirCards.get("Civilian").get(posi), xx, yy, null);
						xx += theirCards.get("Civilian").get(posi).getWidth();
						if (xx == getWidth() - currentPlrOpt.get(0).getWidth())
						{
							yy += theirCards.get("Civilian").get(posi).getHeight();
							xx = currentPlrOpt.get(0).getWidth();
						}
					}
				}
				else if (theirCards.get("Commerce/Trade").size() >= 0 && choice == 2)
				{
					g2.setColor(Color.GRAY);
					Rectangle grayBox = new Rectangle(0, getHeight() / 4, getWidth(), getHeight() / 2);
					g2.fill(grayBox);
					g.drawImage(redX, 0, getHeight() / 4, null );
					int xx = currentPlrOpt.get(0).getWidth(); int yy = getHeight() / 4;
					for (int posi = 0; posi < theirCards.get("Commerce/Trade").size(); posi++)
					{
						theirCards.get("Commerce/Trade").set(posi, resize(theirCards.get("Commerce/Trade").get(posi), theirCards.get("Commerce/Trade").get(posi).getWidth(), getHeight() / 4));
						g.drawImage(theirCards.get("Commerce/Trade").get(posi), xx, yy, null);
						xx += theirCards.get("Commerce/Trade").get(posi).getWidth();
						if (xx == getWidth() - currentPlrOpt.get(0).getWidth())
						{
							yy += theirCards.get("Commerce/Trade").get(posi).getHeight();
							xx = currentPlrOpt.get(0).getWidth();
						}
					}
				} 
				else if (theirCards.get("Guild").size() >= 0 && choice == 3)
				{
					g2.setColor(Color.GRAY);
					Rectangle grayBox = new Rectangle(0, getHeight() / 4, getWidth(), getHeight() / 2);
					g2.fill(grayBox);
					g.drawImage(redX, 0, getHeight() / 4, null );
					int xx = currentPlrOpt.get(0).getWidth(); int yy = getHeight() / 4;
					for (int posi = 0; posi < theirCards.get("Guild").size(); posi++)
					{
						theirCards.get("Guild").set(posi, resize(theirCards.get("Guild").get(posi), theirCards.get("Guild").get(posi).getWidth(), getHeight() / 4));
						g.drawImage(theirCards.get("Guild").get(posi), xx, yy, null);
						xx += theirCards.get("Guild").get(posi).getWidth();
						if (xx == getWidth() - currentPlrOpt.get(0).getWidth())
						{
							yy += theirCards.get("Guild").get(posi).getHeight();
							xx = currentPlrOpt.get(0).getWidth();
						}
					}
				} 
				else if (theirCards.get("Military").size() >= 0 && choice == 4)
				{
					g2.setColor(Color.GRAY);
					Rectangle grayBox = new Rectangle(0, getHeight() / 4, getWidth(), getHeight() / 2);
					g2.fill(grayBox);
					g.drawImage(redX, 0, getHeight() / 4, null );
					int xx = currentPlrOpt.get(0).getWidth(); int yy = getHeight() / 4;
					for (int posi = 0; posi < theirCards.get("Military").size(); posi++)
					{
						theirCards.get("Military").set(posi, resize(theirCards.get("Military").get(posi), theirCards.get("Military").get(posi).getWidth(), getHeight() / 4));
						g.drawImage(theirCards.get("Military").get(posi), xx, yy, null);
						xx += theirCards.get("Military").get(posi).getWidth();
						if (xx == getWidth() - currentPlrOpt.get(0).getWidth())
						{
							yy += theirCards.get("Military").get(posi).getHeight();
							xx = currentPlrOpt.get(0).getWidth();
						}
					}
				} 
				else if (theirCards.get("Resource").size() >= 0 && choice == 5)
				{
					g2.setColor(Color.GRAY);
					Rectangle grayBox = new Rectangle(0, getHeight() / 4, getWidth(), getHeight() / 2);
					g2.fill(grayBox);
					g.drawImage(redX, 0, getHeight() / 4, null );
					int xx = currentPlrOpt.get(0).getWidth(); int yy = getHeight() / 4;
					for (int posi = 0; posi < theirCards.get("Resource").size(); posi++)
					{
						theirCards.get("Resource").set(posi, resize(theirCards.get("Resource").get(posi), theirCards.get("Resource").get(posi).getWidth(), getHeight() / 4));
						g.drawImage(theirCards.get("Resource").get(posi), xx, yy, null);
						xx += theirCards.get("Resource").get(posi).getWidth();
						if (xx == getWidth() - currentPlrOpt.get(0).getWidth())
						{
							yy += theirCards.get("Resource").get(posi).getHeight();
							xx = currentPlrOpt.get(0).getWidth();
						}
					}
				} 
				else if (theirCards.get("Science").size() >= 0 && choice == 6)
				{
					g2.setColor(Color.GRAY);
					Rectangle grayBox = new Rectangle(0, getHeight() / 4, getWidth(), getHeight() / 2);
					g2.fill(grayBox);
					g.drawImage(redX, 0, getHeight() / 4, null );
					int xx = currentPlrOpt.get(0).getWidth(); int yy = getHeight() / 4;
					for (int posi = 0; posi < theirCards.get("Science").size(); posi++)
					{
						theirCards.get("Science").set(posi, resize(theirCards.get("Science").get(posi), theirCards.get("Science").get(posi).getWidth(), getHeight() / 4));
						g.drawImage(theirCards.get("Science").get(posi), xx, yy, null);
						xx += theirCards.get("Science").get(posi).getWidth();
						if (xx == getWidth() - currentPlrOpt.get(0).getWidth())
						{
							yy += theirCards.get("Science").get(posi).getHeight();
							xx = currentPlrOpt.get(0).getWidth();
						}
					}
				} 
			}
			/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			if (theirCards.size() > 0 && rightBig)
			{
				if (theirCards.get("Civilian").size() >= 0 && choice == 1)
				{
					g2.setColor(Color.GRAY);
					Rectangle grayBox = new Rectangle(0, getHeight() / 4, getWidth(), getHeight() / 2);
					g2.fill(grayBox);
					g.drawImage(redX, 0, getHeight() / 4, null );
					int xx = currentPlrOpt.get(0).getWidth(); int yy = getHeight() / 4;
					for (int posi = 0; posi < theirCards.get("Civilian").size(); posi++)
					{
						theirCards.get("Civilian").set(posi, resize(theirCards.get("Civilian").get(posi), theirCards.get("Civilian").get(posi).getWidth(), getHeight() / 4));
						g.drawImage(theirCards.get("Civilian").get(posi), xx, yy, null);
						xx += theirCards.get("Civilian").get(posi).getWidth();
						if (xx == getWidth() - currentPlrOpt.get(0).getWidth())
						{
							yy += theirCards.get("Civilian").get(posi).getHeight();
							xx = currentPlrOpt.get(0).getWidth();
						}
					}
				}
				else if (theirCards.get("Commerce/Trade").size() >= 0 && choice == 2)
				{
					g2.setColor(Color.GRAY);
					Rectangle grayBox = new Rectangle(0, getHeight() / 4, getWidth(), getHeight() / 2);
					g2.fill(grayBox);
					g.drawImage(redX, 0, getHeight() / 4, null );
					int xx = currentPlrOpt.get(0).getWidth(); int yy = getHeight() / 4;
					for (int posi = 0; posi < theirCards.get("Commerce/Trade").size(); posi++)
					{
						theirCards.get("Commerce/Trade").set(posi, resize(theirCards.get("Commerce/Trade").get(posi), theirCards.get("Commerce/Trade").get(posi).getWidth(), getHeight() / 4));
						g.drawImage(theirCards.get("Commerce/Trade").get(posi), xx, yy, null);
						xx += theirCards.get("Commerce/Trade").get(posi).getWidth();
						if (xx == getWidth() - currentPlrOpt.get(0).getWidth())
						{
							yy += theirCards.get("Commerce/Trade").get(posi).getHeight();
							xx = currentPlrOpt.get(0).getWidth();
						}
					}
				} 
				else if (theirCards.get("Guild").size() >= 0 && choice == 3)
				{
					g2.setColor(Color.GRAY);
					Rectangle grayBox = new Rectangle(0, getHeight() / 4, getWidth(), getHeight() / 2);
					g2.fill(grayBox);
					g.drawImage(redX, 0, getHeight() / 4, null );
					int xx = currentPlrOpt.get(0).getWidth(); int yy = getHeight() / 4;
					for (int posi = 0; posi < theirCards.get("Guild").size(); posi++)
					{
						theirCards.get("Guild").set(posi, resize(theirCards.get("Guild").get(posi), theirCards.get("Guild").get(posi).getWidth(), getHeight() / 4));
						g.drawImage(theirCards.get("Guild").get(posi), xx, yy, null);
						xx += theirCards.get("Guild").get(posi).getWidth();
						if (xx == getWidth() - currentPlrOpt.get(0).getWidth())
						{
							yy += theirCards.get("Guild").get(posi).getHeight();
							xx = currentPlrOpt.get(0).getWidth();
						}
					}
				} 
				else if (theirCards.get("Military").size() >= 0 && choice == 4)
				{
					g2.setColor(Color.GRAY);
					Rectangle grayBox = new Rectangle(0, getHeight() / 4, getWidth(), getHeight() / 2);
					g2.fill(grayBox);
					g.drawImage(redX, 0, getHeight() / 4, null );
					int xx = currentPlrOpt.get(0).getWidth(); int yy = getHeight() / 4;
					for (int posi = 0; posi < theirCards.get("Military").size(); posi++)
					{
						theirCards.get("Military").set(posi, resize(theirCards.get("Military").get(posi), theirCards.get("Military").get(posi).getWidth(), getHeight() / 4));
						g.drawImage(theirCards.get("Military").get(posi), xx, yy, null);
						xx += theirCards.get("Military").get(posi).getWidth();
						if (xx == getWidth() - currentPlrOpt.get(0).getWidth())
						{
							yy += theirCards.get("Military").get(posi).getHeight();
							xx = currentPlrOpt.get(0).getWidth();
						}
					}
				} 
				else if (theirCards.get("Resource").size() >= 0 && choice == 5)
				{
					g2.setColor(Color.GRAY);
					Rectangle grayBox = new Rectangle(0, getHeight() / 4, getWidth(), getHeight() / 2);
					g2.fill(grayBox);
					g.drawImage(redX, 0, getHeight() / 4, null );
					int xx = currentPlrOpt.get(0).getWidth(); int yy = getHeight() / 4;
					for (int posi = 0; posi < theirCards.get("Resource").size(); posi++)
					{
						theirCards.get("Resource").set(posi, resize(theirCards.get("Resource").get(posi), theirCards.get("Resource").get(posi).getWidth(), getHeight() / 4));
						g.drawImage(theirCards.get("Resource").get(posi), xx, yy, null);
						xx += theirCards.get("Resource").get(posi).getWidth();
						if (xx == getWidth() - currentPlrOpt.get(0).getWidth())
						{
							yy += theirCards.get("Resource").get(posi).getHeight();
							xx = currentPlrOpt.get(0).getWidth();
						}
					}
				} 
				else if (theirCards.get("Science").size() >= 0 && choice == 6)
				{
					g2.setColor(Color.GRAY);
					Rectangle grayBox = new Rectangle(0, getHeight() / 4, getWidth(), getHeight() / 2);
					g2.fill(grayBox);
					g.drawImage(redX, 0, getHeight() / 4, null );
					int xx = currentPlrOpt.get(0).getWidth(); int yy = getHeight() / 4;
					for (int posi = 0; posi < theirCards.get("Science").size(); posi++)
					{
						theirCards.get("Science").set(posi, resize(theirCards.get("Science").get(posi), theirCards.get("Science").get(posi).getWidth(), getHeight() / 4));
						g.drawImage(theirCards.get("Science").get(posi), xx, yy, null);
						xx += theirCards.get("Science").get(posi).getWidth();
						if (xx == getWidth() - currentPlrOpt.get(0).getWidth())
						{
							yy += theirCards.get("Science").get(posi).getHeight();
							xx = currentPlrOpt.get(0).getWidth();
						}
					}
				} 
			}
			///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			if (theirCards.size() > 0 && leftBig)
			{
				if (theirCards.get("Civilian").size() >= 0 && choice == 1)
				{
					g2.setColor(Color.GRAY);
					Rectangle grayBox = new Rectangle(0, getHeight() / 4, getWidth(), getHeight() / 2);
					g2.fill(grayBox);
					g.drawImage(redX, 0, getHeight() / 4, null );
					int xx = currentPlrOpt.get(0).getWidth(); int yy = getHeight() / 4;
					for (int posi = 0; posi < theirCards.get("Civilian").size(); posi++)
					{
						theirCards.get("Civilian").set(posi, resize(theirCards.get("Civilian").get(posi), theirCards.get("Civilian").get(posi).getWidth(), getHeight() / 4));
						g.drawImage(theirCards.get("Civilian").get(posi), xx, yy, null);
						xx += theirCards.get("Civilian").get(posi).getWidth();
						if (xx == getWidth() - currentPlrOpt.get(0).getWidth())
						{
							yy += theirCards.get("Civilian").get(posi).getHeight();
							xx = currentPlrOpt.get(0).getWidth();
						}
					}
				}
				else if (theirCards.get("Commerce/Trade").size() >= 0 && choice == 2)
				{
					g2.setColor(Color.GRAY);
					Rectangle grayBox = new Rectangle(0, getHeight() / 4, getWidth(), getHeight() / 2);
					g2.fill(grayBox);
					g.drawImage(redX, 0, getHeight() / 4, null );
					int xx = currentPlrOpt.get(0).getWidth(); int yy = getHeight() / 4;
					for (int posi = 0; posi < theirCards.get("Commerce/Trade").size(); posi++)
					{
						theirCards.get("Commerce/Trade").set(posi, resize(theirCards.get("Commerce/Trade").get(posi), theirCards.get("Commerce/Trade").get(posi).getWidth(), getHeight() / 4));
						g.drawImage(theirCards.get("Commerce/Trade").get(posi), xx, yy, null);
						xx += theirCards.get("Commerce/Trade").get(posi).getWidth();
						if (xx == getWidth() - currentPlrOpt.get(0).getWidth())
						{
							yy += theirCards.get("Commerce/Trade").get(posi).getHeight();
							xx = currentPlrOpt.get(0).getWidth();
						}
					}
				} 
				else if (theirCards.get("Guild").size() >= 0 && choice == 3)
				{
					g2.setColor(Color.GRAY);
					Rectangle grayBox = new Rectangle(0, getHeight() / 4, getWidth(), getHeight() / 2);
					g2.fill(grayBox);
					g.drawImage(redX, 0, getHeight() / 4, null );
					int xx = currentPlrOpt.get(0).getWidth(); int yy = getHeight() / 4;
					for (int posi = 0; posi < theirCards.get("Guild").size(); posi++)
					{
						theirCards.get("Guild").set(posi, resize(theirCards.get("Guild").get(posi), theirCards.get("Guild").get(posi).getWidth(), getHeight() / 4));
						g.drawImage(theirCards.get("Guild").get(posi), xx, yy, null);
						xx += theirCards.get("Guild").get(posi).getWidth();
						if (xx == getWidth() - currentPlrOpt.get(0).getWidth())
						{
							yy += theirCards.get("Guild").get(posi).getHeight();
							xx = currentPlrOpt.get(0).getWidth();
						}
					}
				} 
				else if (theirCards.get("Military").size() >= 0 && choice == 4)
				{
					g2.setColor(Color.GRAY);
					Rectangle grayBox = new Rectangle(0, getHeight() / 4, getWidth(), getHeight() / 2);
					g2.fill(grayBox);
					g.drawImage(redX, 0, getHeight() / 4, null );
					int xx = currentPlrOpt.get(0).getWidth(); int yy = getHeight() / 4;
					for (int posi = 0; posi < theirCards.get("Military").size(); posi++)
					{
						theirCards.get("Military").set(posi, resize(theirCards.get("Military").get(posi), theirCards.get("Military").get(posi).getWidth(), getHeight() / 4));
						g.drawImage(theirCards.get("Military").get(posi), xx, yy, null);
						xx += theirCards.get("Military").get(posi).getWidth();
						if (xx == getWidth() - currentPlrOpt.get(0).getWidth())
						{
							yy += theirCards.get("Military").get(posi).getHeight();
							xx = currentPlrOpt.get(0).getWidth();
						}
					}
				} 
				else if (theirCards.get("Resource").size() >= 0 && choice == 5)
				{
					g2.setColor(Color.GRAY);
					Rectangle grayBox = new Rectangle(0, getHeight() / 4, getWidth(), getHeight() / 2);
					g2.fill(grayBox);
					g.drawImage(redX, 0, getHeight() / 4, null );
					int xx = currentPlrOpt.get(0).getWidth(); int yy = getHeight() / 4;
					for (int posi = 0; posi < theirCards.get("Resource").size(); posi++)
					{
						theirCards.get("Resource").set(posi, resize(theirCards.get("Resource").get(posi), theirCards.get("Resource").get(posi).getWidth(), getHeight() / 4));
						g.drawImage(theirCards.get("Resource").get(posi), xx, yy, null);
						xx += theirCards.get("Resource").get(posi).getWidth();
						if (xx == getWidth() - currentPlrOpt.get(0).getWidth())
						{
							yy += theirCards.get("Resource").get(posi).getHeight();
							xx = currentPlrOpt.get(0).getWidth();
						}
					}
				} 
				else if (theirCards.get("Science").size() >= 0 && choice == 6)
				{
					g2.setColor(Color.GRAY);
					Rectangle grayBox = new Rectangle(0, getHeight() / 4, getWidth(), getHeight() / 2);
					g2.fill(grayBox);
					g.drawImage(redX, 0, getHeight() / 4, null );
					int xx = currentPlrOpt.get(0).getWidth(); int yy = getHeight() / 4;
					for (int posi = 0; posi < theirCards.get("Science").size(); posi++)
					{
						theirCards.get("Science").set(posi, resize(theirCards.get("Science").get(posi), theirCards.get("Science").get(posi).getWidth(), getHeight() / 4));
						g.drawImage(theirCards.get("Science").get(posi), xx, yy, null);
						xx += theirCards.get("Science").get(posi).getWidth();
						if (xx == getWidth() - currentPlrOpt.get(0).getWidth())
						{
							yy += theirCards.get("Science").get(posi).getHeight();
							xx = currentPlrOpt.get(0).getWidth();
						}
					}
				} 
			}
			////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			if (leftSide)
			{
				g2.setColor(Color.DARK_GRAY);
				Rectangle grayBox = new Rectangle(0, getHeight() / 2, currentPlrOpt.get(0).getWidth() * 6, currentPlrOpt.get(0).getHeight());
				g2.fill(grayBox);
				g2.setColor(Color.RED);
				Rectangle miniBox = new Rectangle(0, getHeight() / 2, currentPlrOpt.get(0).getWidth(), currentPlrOpt.get(0).getHeight());
				g2.draw(miniBox);
				miniBox = new Rectangle(currentPlrOpt.get(0).getWidth(), getHeight() / 2, currentPlrOpt.get(0).getWidth(), currentPlrOpt.get(0).getHeight());
				g2.draw(miniBox);
				miniBox = new Rectangle(currentPlrOpt.get(0).getWidth() * 2, getHeight() / 2, currentPlrOpt.get(0).getWidth(), currentPlrOpt.get(0).getHeight());
				g2.draw(miniBox);
				miniBox = new Rectangle(currentPlrOpt.get(0).getWidth() * 3, getHeight() / 2, currentPlrOpt.get(0).getWidth(), currentPlrOpt.get(0).getHeight());
				g2.draw(miniBox);
				miniBox = new Rectangle(currentPlrOpt.get(0).getWidth() * 4, getHeight() / 2, currentPlrOpt.get(0).getWidth(), currentPlrOpt.get(0).getHeight());
				g2.draw(miniBox);
				miniBox = new Rectangle(currentPlrOpt.get(0).getWidth() * 5, getHeight() / 2, currentPlrOpt.get(0).getWidth(), currentPlrOpt.get(0).getHeight());
				g2.draw(miniBox);
				g2.setColor(Color.BLACK);
				
				g2.setFont(new Font("Times New Roman", Font.BOLD, 30));
				g2.drawString("Click to see", 5, getHeight() / 2 + 25);
				g2.drawString("Click to see", currentPlrOpt.get(0).getWidth() + 5, getHeight() / 2 + 25);
				g2.drawString("Click to see", currentPlrOpt.get(0).getWidth() * 2 + 5, getHeight() / 2 + 25);
				g2.drawString("Click to see", currentPlrOpt.get(0).getWidth() * 3 + 5, getHeight() / 2 + 25);
				g2.drawString("Click to see", currentPlrOpt.get(0).getWidth() * 4 + 5, getHeight() / 2 + 25);
				g2.drawString("Click to see", currentPlrOpt.get(0).getWidth() * 5 + 5, getHeight() / 2 + 25);
				
				g2.setFont(new Font("Times New Roman", Font.BOLD, 23));
				g2.drawString("Civilian cards", 5, getHeight() / 2 + 50);
				g2.setFont(new Font("Times New Roman", Font.BOLD, 20));
				g2.drawString("Commerce/Trade", currentPlrOpt.get(0).getWidth() + 5, getHeight() / 2 + 50);
				g2.setFont(new Font("Times New Roman", Font.BOLD, 23));
				g2.drawString("Guild cards", currentPlrOpt.get(0).getWidth() * 2 + 5, getHeight() / 2 + 50);
				g2.drawString("Military cards", currentPlrOpt.get(0).getWidth() * 3 + 5, getHeight() / 2 + 50);
				g2.drawString("Resource cards", currentPlrOpt.get(0).getWidth() * 4 + 5, getHeight() / 2 + 50);
				g2.drawString("Science cards", currentPlrOpt.get(0).getWidth() * 5 + 5, getHeight() / 2 + 50);
				
				if (clockWise)
				{
					g2.setFont(new Font("Times New Roman", Font.BOLD, 23));
					g2.drawString(currPlayer[turnPrev].getHand().get("Civilian").size() + "", 5, getHeight() / 2 + 75);
					g2.setFont(new Font("Times New Roman", Font.BOLD, 20));
					g2.drawString(currPlayer[turnPrev].getHand().get("Commerce/Trade").size() + "", currentPlrOpt.get(0).getWidth() + 5, getHeight() / 2 + 75);
					g2.setFont(new Font("Times New Roman", Font.BOLD, 23));
					g2.drawString(currPlayer[turnPrev].getHand().get("Guild").size() + "", currentPlrOpt.get(0).getWidth() * 2 + 5, getHeight() / 2 + 75);
					g2.drawString(currPlayer[turnPrev].getHand().get("Military").size() + "", currentPlrOpt.get(0).getWidth() * 3 + 5, getHeight() / 2 + 75);
					g2.drawString(currPlayer[turnPrev].getHand().get("Resource").size() + "", currentPlrOpt.get(0).getWidth() * 4 + 5, getHeight() / 2 + 75);
					g2.drawString(currPlayer[turnPrev].getHand().get("Science").size() + "", currentPlrOpt.get(0).getWidth() * 5 + 5, getHeight() / 2 + 75);
				}
				else
				{
					g2.setFont(new Font("Times New Roman", Font.BOLD, 23));
					g2.drawString(currPlayer[turnNext].getHand().get("Civilian").size() + "", 5, getHeight() / 2 + 75);
					g2.drawString(currPlayer[turnNext].getHand().get("Commerce/Trade").size() + "", currentPlrOpt.get(0).getWidth() + 5, getHeight() / 2 + 75);
					g2.drawString(currPlayer[turnNext].getHand().get("Guild").size() + "", currentPlrOpt.get(0).getWidth() * 2 + 5, getHeight() / 2 + 75);
					g2.drawString(currPlayer[turnNext].getHand().get("Military").size() + "", currentPlrOpt.get(0).getWidth() * 3 + 5, getHeight() / 2 + 75);
					g2.drawString(currPlayer[turnNext].getHand().get("Resource").size() + "", currentPlrOpt.get(0).getWidth() * 4 + 5, getHeight() / 2 + 75);
					g2.drawString(currPlayer[turnNext].getHand().get("Science").size() + "", currentPlrOpt.get(0).getWidth() * 5 + 5, getHeight() / 2 + 75);
				}
			}
			
			if (rightSide)
			{
				g2.setColor(Color.DARK_GRAY);
				Rectangle grayBox = new Rectangle(0, getHeight() / 2, currentPlrOpt.get(0).getWidth() * 6, currentPlrOpt.get(0).getHeight());
				g2.fill(grayBox);
				g2.setColor(Color.RED);
				Rectangle miniBox = new Rectangle(0, getHeight() / 2, currentPlrOpt.get(0).getWidth(), currentPlrOpt.get(0).getHeight());
				g2.draw(miniBox);
				miniBox = new Rectangle(currentPlrOpt.get(0).getWidth(), getHeight() / 2, currentPlrOpt.get(0).getWidth(), currentPlrOpt.get(0).getHeight());
				g2.draw(miniBox);
				miniBox = new Rectangle(currentPlrOpt.get(0).getWidth() * 2, getHeight() / 2, currentPlrOpt.get(0).getWidth(), currentPlrOpt.get(0).getHeight());
				g2.draw(miniBox);
				miniBox = new Rectangle(currentPlrOpt.get(0).getWidth() * 3, getHeight() / 2, currentPlrOpt.get(0).getWidth(), currentPlrOpt.get(0).getHeight());
				g2.draw(miniBox);
				miniBox = new Rectangle(currentPlrOpt.get(0).getWidth() * 4, getHeight() / 2, currentPlrOpt.get(0).getWidth(), currentPlrOpt.get(0).getHeight());
				g2.draw(miniBox);
				miniBox = new Rectangle(currentPlrOpt.get(0).getWidth() * 5, getHeight() / 2, currentPlrOpt.get(0).getWidth(), currentPlrOpt.get(0).getHeight());
				g2.draw(miniBox);
				g2.setColor(Color.BLACK);
				
				g2.setFont(new Font("Times New Roman", Font.BOLD, 30));
				g2.drawString("Click to see", 5, getHeight() / 2 + 25);
				g2.drawString("Click to see", currentPlrOpt.get(0).getWidth() + 5, getHeight() / 2 + 25);
				g2.drawString("Click to see", currentPlrOpt.get(0).getWidth() * 2 + 5, getHeight() / 2 + 25);
				g2.drawString("Click to see", currentPlrOpt.get(0).getWidth() * 3 + 5, getHeight() / 2 + 25);
				g2.drawString("Click to see", currentPlrOpt.get(0).getWidth() * 4 + 5, getHeight() / 2 + 25);
				g2.drawString("Click to see", currentPlrOpt.get(0).getWidth() * 5 + 5, getHeight() / 2 + 25);
				
				g2.setFont(new Font("Times New Roman", Font.BOLD, 23));
				g2.drawString("Civilian cards", 5, getHeight() / 2 + 50);
				g2.setFont(new Font("Times New Roman", Font.BOLD, 20));
				g2.drawString("Commerce/Trade", currentPlrOpt.get(0).getWidth() + 5, getHeight() / 2 + 50);
				g2.setFont(new Font("Times New Roman", Font.BOLD, 23));
				g2.drawString("Guild cards", currentPlrOpt.get(0).getWidth() * 2 + 5, getHeight() / 2 + 50);
				g2.drawString("Military cards", currentPlrOpt.get(0).getWidth() * 3 + 5, getHeight() / 2 + 50);
				g2.drawString("Resource cards", currentPlrOpt.get(0).getWidth() * 4 + 5, getHeight() / 2 + 50);
				g2.drawString("Science cards", currentPlrOpt.get(0).getWidth() * 5 + 5, getHeight() / 2 + 50);
				
				if (clockWise)
				{
					g2.setFont(new Font("Times New Roman", Font.BOLD, 23));
					g2.drawString(currPlayer[turnNext].getHand().get("Civilian").size() + "", 5, getHeight() / 2 + 75);
					g2.setFont(new Font("Times New Roman", Font.BOLD, 20));
					g2.drawString(currPlayer[turnNext].getHand().get("Commerce/Trade").size() + "", currentPlrOpt.get(0).getWidth() + 5, getHeight() / 2 + 75);
					g2.setFont(new Font("Times New Roman", Font.BOLD, 23));
					g2.drawString(currPlayer[turnNext].getHand().get("Guild").size() + "", currentPlrOpt.get(0).getWidth() * 2 + 5, getHeight() / 2 + 75);
					g2.drawString(currPlayer[turnNext].getHand().get("Military").size() + "", currentPlrOpt.get(0).getWidth() * 3 + 5, getHeight() / 2 + 75);
					g2.drawString(currPlayer[turnNext].getHand().get("Resource").size() + "", currentPlrOpt.get(0).getWidth() * 4 + 5, getHeight() / 2 + 75);
					g2.drawString(currPlayer[turnNext].getHand().get("Science").size() + "", currentPlrOpt.get(0).getWidth() * 5 + 5, getHeight() / 2 + 75);
				}
				else
				{
					g2.setFont(new Font("Times New Roman", Font.BOLD, 23));
					g2.drawString(currPlayer[turnPrev].getHand().get("Civilian").size() + "", 5, getHeight() / 2 + 75);
					g2.drawString(currPlayer[turnPrev].getHand().get("Commerce/Trade").size() + "", currentPlrOpt.get(0).getWidth() + 5, getHeight() / 2 + 75);
					g2.drawString(currPlayer[turnPrev].getHand().get("Guild").size() + "", currentPlrOpt.get(0).getWidth() * 2 + 5, getHeight() / 2 + 75);
					g2.drawString(currPlayer[turnPrev].getHand().get("Military").size() + "", currentPlrOpt.get(0).getWidth() * 3 + 5, getHeight() / 2 + 75);
					g2.drawString(currPlayer[turnPrev].getHand().get("Resource").size() + "", currentPlrOpt.get(0).getWidth() * 4 + 5, getHeight() / 2 + 75);
					g2.drawString(currPlayer[turnPrev].getHand().get("Science").size() + "", currentPlrOpt.get(0).getWidth() * 5 + 5, getHeight() / 2 + 75);
				}
			}
		}
		if (end)
		{
			Rectangle finalBox = new Rectangle(0, 0, getWidth(), getHeight());
			g2.setColor(Color.cyan);
			g2.fill(finalBox);
			
			g2.setColor(Color.BLACK);
			g2.setFont(new Font("Times New Roman", Font.BOLD, 50));
			
			g2.drawString("Player 1: ", 0, 50);
			g2.drawString("Losses: " + arAl[0].get(0), 0, 100);
			g2.drawString("Wins: " + arAl[0].get(1), 0, 150);
			g2.drawString("Coins: " + arAl[0].get(2), 0, 200);
			g2.drawString("Stage level: " + arAl[0].get(3), 0, 250);
			g2.drawString("Civil cards: " + arAl[0].get(4), 0, 300);
			g2.drawString("Science cards: " + arAl[0].get(5), 0, 350);
			g2.drawString("Commercial cards: " + arAl[0].get(6), 0, 400);
			g2.drawString("Guild cards: " + arAl[0].get(7), 0, 450);
			g2.drawString("Score = " + arAl[0].get(8), 0, 500);
			
			g2.drawString("Player 2: ", 500, 50);
			g2.drawString("Losses: " + arAl[1].get(0), 500, 100);
			g2.drawString("Wins: " + arAl[1].get(1), 500, 150);
			g2.drawString("Coins: " + arAl[1].get(2), 500, 200);
			g2.drawString("Stage level: " + arAl[1].get(3), 500, 250);
			g2.drawString("Civil cards: " + arAl[1].get(4), 500, 300);
			g2.drawString("Science cards: " + arAl[1].get(5), 500, 350);
			g2.drawString("Commercial cards: " + arAl[1].get(6), 500, 400);
			g2.drawString("Guild cards: " + arAl[1].get(7), 500, 450);
			g2.drawString("Score = " + arAl[1].get(8), 500, 500);
			
			g2.drawString("Player 3: ", 1000, 50);
			g2.drawString("Losses: " + arAl[2].get(0), 1000, 100);
			g2.drawString("Wins: " + arAl[2].get(1), 1000, 150);
			g2.drawString("Coins: " + arAl[2].get(2), 1000, 200);
			g2.drawString("Stage level: " + arAl[2].get(3), 1000, 250);
			g2.drawString("Civil cards: " + arAl[2].get(4), 1000, 300);
			g2.drawString("Science cards: " + arAl[2].get(5), 1000, 350);
			g2.drawString("Commercial cards: " + arAl[2].get(6), 1000, 400);
			g2.drawString("Guild cards: " + arAl[2].get(7), 1000, 450);
			g2.drawString("Score = " + arAl[2].get(8), 1000, 500);
		}
	}
	
	public static BufferedImage resize(BufferedImage img, int newW, int newH)
	{ 
	    Image tmp = img.getScaledInstance(newW, newH, Image.SCALE_SMOOTH);
	    BufferedImage dimg = new BufferedImage(newW, newH, BufferedImage.TYPE_INT_ARGB);

	    Graphics2D g2d = dimg.createGraphics();
	    g2d.drawImage(tmp, 0, 0, null);
	    g2d.dispose();

	    return dimg;
	}  
	
	public void setPlayers(Player[] p)
	{
		players = new ArrayList<BufferedImage>();
		try {
			BufferedImage temp = ImageIO.read(new File("WonderPNG/" + p[0].getWonder().getName() + "A.png"));
			players.add(temp);
			temp = ImageIO.read(new File("WonderPNG/" + p[1].getWonder().getName() + "A.png"));
			players.add(temp);
			temp = ImageIO.read(new File("WonderPNG/" + p[2].getWonder().getName() + "A.png"));
			players.add(temp);
		}
		catch (Exception e) {
			System.out.println("error");
		}
		repaint();
	}
	
	public void updateAge()
	{
		age++;
	}
	
	public int chooseAction()
	{
		int action = 0;
		int tempWidth = getWidth() - players.get(1).getWidth() * 2;
		x = 0; y = 0;
		while (true)
		{
			while (x == 0 && y == 0)
			{
				try {
					TimeUnit.MICROSECONDS.sleep(1000);
				}
				catch(Exception e) {
					System.out.println("error");
				}
			}
			if (x > players.get(1).getWidth() && x < players.get(1).getWidth() + tempWidth / 4 && y > players.get(1).getHeight() / 2 * 3 && y < players.get(1).getHeight() / 2 * 3 + players.get(1).getHeight() / 4)
			{
				action = 1;
				break;
			}
			else if (x > players.get(1).getWidth() + tempWidth / 4 + tempWidth / 8 && x < players.get(1).getWidth() + tempWidth / 2 + tempWidth / 8 && y > players.get(1).getHeight() / 2 * 3 && y < players.get(1).getHeight() / 2 * 3 + players.get(1).getHeight() / 4)
			{
				action = 2;
				break;
			}
			else if (x > players.get(1).getWidth() + tempWidth - tempWidth / 4 && x < players.get(1).getWidth() + tempWidth && y > players.get(1).getHeight() / 2 * 3 && y < players.get(1).getHeight() / 2 * 3 + players.get(1).getHeight() / 4)
			{
				action = 3;
				break;
			}
			x = 0; y = 0;
		}
		return action;
	}
	
	public void pullUpMain(int one, int two, Player p)
	{
		ArrayList<BufferedImage> temp = new ArrayList<BufferedImage>();
		mainThing = true;
		choice = 0;
		while (true)
		{
			while (x == 0 && y == 0)
			{
				try {
					TimeUnit.MICROSECONDS.sleep(1000);
				}
				catch(Exception e) {
					System.out.println("error");
				}
			}
			
			if(one > 0 && one < currentPlrOpt.get(0).getWidth() && two > getHeight() - currentPlrOpt.get(0).getHeight())
			{
				for (Card c : p.getHand().get("Civilian"))
				{
					try {
						BufferedImage tempImg = ImageIO.read(new File("CardPNG/" + c.getName() + ".png"));
						temp.add(tempImg);
					}
					catch (Exception e) {
						System.out.println("error");
					}
				}
				theirCards.put("Civilian", temp);
				choice = 1;
				repaint();
			}	
			else if(one > currentPlrOpt.get(0).getWidth() && one < currentPlrOpt.get(0).getWidth() * 2 && two > getHeight() - currentPlrOpt.get(0).getHeight())
			{
				for (Card c : p.getHand().get("Commerce/Trade"))
				{
					try {
						BufferedImage tempImg = ImageIO.read(new File("CardPNG/" + c.getName() + ".png"));
						temp.add(tempImg);
					}
					catch (Exception e) {
						System.out.println("error");
					}
				}
				theirCards.put("Commerce/Trade", temp);
				choice = 2;
				repaint();
			}
			else if(one > currentPlrOpt.get(0).getWidth() * 2 && one < currentPlrOpt.get(0).getWidth() * 3 && two > getHeight() - currentPlrOpt.get(0).getHeight())
			{
				for (Card c : p.getHand().get("Guild"))
				{
					try {
						BufferedImage tempImg = ImageIO.read(new File("CardPNG/" + c.getName() + ".png"));
						temp.add(tempImg);
					}
					catch (Exception e) {
						System.out.println("error");
					}
				}
				theirCards.put("Guild", temp);
				choice = 3;
				repaint();
			}
			else if(one > currentPlrOpt.get(0).getWidth() * 3 && one < currentPlrOpt.get(0).getWidth() * 4 && two > getHeight() - currentPlrOpt.get(0).getHeight())
			{
				for (Card c : p.getHand().get("Military"))
				{
					try {
						BufferedImage tempImg = ImageIO.read(new File("CardPNG/" + c.getName() + ".png"));
						temp.add(tempImg);
					}
					catch (Exception e) {
						System.out.println("error");
					}
				}
				theirCards.put("Military", temp);
				choice = 4;
				repaint();
			}
			else if(one > currentPlrOpt.get(0).getWidth() * 4 && one < currentPlrOpt.get(0).getWidth() * 5 && two > getHeight() - currentPlrOpt.get(0).getHeight())
			{
				for (Card c : p.getHand().get("Resource"))
				{
					try {
						BufferedImage tempImg = ImageIO.read(new File("CardPNG/" + c.getName() + ".png"));
						temp.add(tempImg);
					}
					catch (Exception e) {
						System.out.println("error");
					}
				}
				theirCards.put("Resource", temp);
				choice = 5;
				repaint();
			}
			else if(one > currentPlrOpt.get(0).getWidth() * 5 && one < currentPlrOpt.get(0).getWidth() * 6 && two > getHeight() - currentPlrOpt.get(0).getHeight())
			{
				for (Card c : p.getHand().get("Science"))
				{
					try {
						BufferedImage tempImg = ImageIO.read(new File("CardPNG/" + c.getName() + ".png"));
						temp.add(tempImg);
					}
					catch (Exception e) {
						System.out.println("error");
					}
				}
				theirCards.put("Science", temp);
				choice = 6;
				repaint();
			}
			if (x > 0 && x < 50 && y > getHeight() / 4 && y <  getHeight() / 4 + 50)
			{
				choice = 0;
				mainThing = false;
				repaint();
				break;
			}
			one = 0; two = 0;
			x = 0; y = 0;
		}
	}
		
	public void pullUpLeft(Player p)
	{
		ArrayList<BufferedImage> temp = new ArrayList<BufferedImage>();
		choice = 0;
		leftSide = true;
		repaint();
		x = 0; y = 0;
		while (true)
		{
			while (x == 0 && y == 0)
			{
				try {
					TimeUnit.MICROSECONDS.sleep(1000);
				}
				catch(Exception e) {
					System.out.println("error");
				}
			}
			if (x > 0 && x < currentPlrOpt.get(0).getWidth() && y > getHeight() / 2 && y < getHeight() / 2 + currentPlrOpt.get(0).getHeight())
			{
				leftSide = false;
				leftBig = true;
				for (Card c : p.getHand().get("Civilian"))
				{
					try {
						BufferedImage tempImg = ImageIO.read(new File("CardPNG/" + c.getName() + ".png"));
						temp.add(tempImg);
					}
					catch (Exception e) {
						System.out.println("error");
					}
				}
				theirCards.put("Civilian", temp);
				choice = 1;
				repaint();
			}
			else if (x > currentPlrOpt.get(0).getWidth() && x < currentPlrOpt.get(0).getWidth() * 2 && y > getHeight() / 2 && y < getHeight() / 2 + currentPlrOpt.get(0).getHeight())
			{
				leftSide = false;
				leftBig = true;
				for (Card c : p.getHand().get("Commerce/Trade"))
				{
					try {
						BufferedImage tempImg = ImageIO.read(new File("CardPNG/" + c.getName() + ".png"));
						temp.add(tempImg);
					}
					catch (Exception e) {
						System.out.println("error");
					}
				}
				theirCards.put("Commerce/Trade", temp);
				choice = 2;
				repaint();
			}
			else if (x > currentPlrOpt.get(0).getWidth() * 2 && x < currentPlrOpt.get(0).getWidth() * 3 && y > getHeight() / 2 && y < getHeight() / 2 + currentPlrOpt.get(0).getHeight())
			{
				leftSide = false;
				leftBig = true;
				for (Card c : p.getHand().get("Guild"))
				{
					try {
						BufferedImage tempImg = ImageIO.read(new File("CardPNG/" + c.getName() + ".png"));
						temp.add(tempImg);
					}
					catch (Exception e) {
						System.out.println("error");
					}
				}
				theirCards.put("Guild", temp);
				choice = 3;
				repaint();
			}
			else if (x > currentPlrOpt.get(0).getWidth() * 3 && x < currentPlrOpt.get(0).getWidth() * 4 && y > getHeight() / 2 && y < getHeight() / 2 + currentPlrOpt.get(0).getHeight())
			{
				leftSide = false;
				leftBig = true;
				for (Card c : p.getHand().get("Military"))
				{
					try {
						BufferedImage tempImg = ImageIO.read(new File("CardPNG/" + c.getName() + ".png"));
						temp.add(tempImg);
					}
					catch (Exception e) {
						System.out.println("error");
					}
				}
				theirCards.put("Military", temp);
				choice = 4;
				repaint();
			}
			else if (x > currentPlrOpt.get(0).getWidth() * 4 && x < currentPlrOpt.get(0).getWidth() * 5 && y > getHeight() / 2 && y < getHeight() / 2 + currentPlrOpt.get(0).getHeight())
			{
				leftSide = false;
				leftBig = true;
				for (Card c : p.getHand().get("Resource"))
				{
					try {
						BufferedImage tempImg = ImageIO.read(new File("CardPNG/" + c.getName() + ".png"));
						temp.add(tempImg);
					}
					catch (Exception e) {
						System.out.println("error");
					}
				}
				theirCards.put("Resource", temp);
				choice = 5;
				repaint();
			}
			else if (x > currentPlrOpt.get(0).getWidth() * 5 && x < currentPlrOpt.get(0).getWidth() * 6 && y > getHeight() / 2 && y < getHeight() / 2 + currentPlrOpt.get(0).getHeight())
			{
				leftSide = false;
				leftBig = true;
				for (Card c : p.getHand().get("Science"))
				{
					try {
						BufferedImage tempImg = ImageIO.read(new File("CardPNG/" + c.getName() + ".png"));
						temp.add(tempImg);
					}
					catch (Exception e) {
						System.out.println("error");
					}
				}
				theirCards.put("Science", temp);
				choice = 6;
				repaint();
			}
			if (x > 0 && x < 50 && y > getHeight() / 4 && y <  getHeight() / 4 + 50)
			{
				choice = 0;
				mainThing = false;
				repaint();
				break;
			}
			x = 0; y = 0;
		}
	}
		
	public void pullUpRight(int one, int two, Player p)
	{
		ArrayList<BufferedImage> temp = new ArrayList<BufferedImage>();
		choice = 0;
		rightSide = true;
		repaint();
		x = 0; y = 0;
		while (true)
		{
			while (x == 0 && y == 0)
			{
				try {
					TimeUnit.MICROSECONDS.sleep(1000);
				}
				catch(Exception e) {
					System.out.println("error");
				}
			}
			if (x > 0 && x < currentPlrOpt.get(0).getWidth() && y > getHeight() / 2 && y < getHeight() / 2 + currentPlrOpt.get(0).getHeight())
			{
				rightSide = false;
				rightBig = true;
				for (Card c : p.getHand().get("Civilian"))
				{
					try {
						BufferedImage tempImg = ImageIO.read(new File("CardPNG/" + c.getName() + ".png"));
						temp.add(tempImg);
					}
					catch (Exception e) {
						System.out.println("error");
					}
				}
				theirCards.put("Civilian", temp);
				choice = 1;
				repaint();
			}
			else if (x > currentPlrOpt.get(0).getWidth() && x < currentPlrOpt.get(0).getWidth() * 2 && y > getHeight() / 2 && y < getHeight() / 2 + currentPlrOpt.get(0).getHeight())
			{
				rightSide = false;
				rightBig = true;
				for (Card c : p.getHand().get("Commerce/Trade"))
				{
					try {
						BufferedImage tempImg = ImageIO.read(new File("CardPNG/" + c.getName() + ".png"));
						temp.add(tempImg);
					}
					catch (Exception e) {
						System.out.println("error");
					}
				}
				theirCards.put("Commerce/Trade", temp);
				choice = 2;
				repaint();
			}
			else if (x > currentPlrOpt.get(0).getWidth() * 2 && x < currentPlrOpt.get(0).getWidth() * 3 && y > getHeight() / 2 && y < getHeight() / 2 + currentPlrOpt.get(0).getHeight())
			{
				rightSide = false;
				rightBig = true;
				for (Card c : p.getHand().get("Guild"))
				{
					try {
						BufferedImage tempImg = ImageIO.read(new File("CardPNG/" + c.getName() + ".png"));
						temp.add(tempImg);
					}
					catch (Exception e) {
						System.out.println("error");
					}
				}
				theirCards.put("Guild", temp);
				choice = 3;
				repaint();
			}
			else if (x > currentPlrOpt.get(0).getWidth() * 3 && x < currentPlrOpt.get(0).getWidth() * 4 && y > getHeight() / 2 && y < getHeight() / 2 + currentPlrOpt.get(0).getHeight())
			{
				rightSide = false;
				rightBig = true;
				for (Card c : p.getHand().get("Military"))
				{
					try {
						BufferedImage tempImg = ImageIO.read(new File("CardPNG/" + c.getName() + ".png"));
						temp.add(tempImg);
					}
					catch (Exception e) {
						System.out.println("error");
					}
				}
				theirCards.put("Military", temp);
				choice = 4;
				repaint();
			}
			else if (x > currentPlrOpt.get(0).getWidth() * 4 && x < currentPlrOpt.get(0).getWidth() * 5 && y > getHeight() / 2 && y < getHeight() / 2 + currentPlrOpt.get(0).getHeight())
			{
				rightSide = false;
				rightBig = true;
				for (Card c : p.getHand().get("Resource"))
				{
					try {
						BufferedImage tempImg = ImageIO.read(new File("CardPNG/" + c.getName() + ".png"));
						temp.add(tempImg);
					}
					catch (Exception e) {
						System.out.println("error");
					}
				}
				theirCards.put("Resource", temp);
				choice = 5;
				repaint();
			}
			else if (x > currentPlrOpt.get(0).getWidth() * 5 && x < currentPlrOpt.get(0).getWidth() * 6 && y > getHeight() / 2 && y < getHeight() / 2 + currentPlrOpt.get(0).getHeight())
			{
				rightSide = false;
				rightBig = true;
				for (Card c : p.getHand().get("Science"))
				{
					try {
						BufferedImage tempImg = ImageIO.read(new File("CardPNG/" + c.getName() + ".png"));
						temp.add(tempImg);
					}
					catch (Exception e) {
						System.out.println("error");
					}
				}
				theirCards.put("Science", temp);
				choice = 6;
				repaint();
			}
			if (x > 0 && x < 50 && y > getHeight() / 4 && y <  getHeight() / 4 + 50)
			{
				choice = 0;
				mainThing = false;
				repaint();
				break;
			}
			x = 0; y = 0;
		}
	}
	
	public void endAll(ArrayList<Integer>[] arAl)
	{
		end = true;
		this.arAl = arAl;
		repaint();
	}
}
