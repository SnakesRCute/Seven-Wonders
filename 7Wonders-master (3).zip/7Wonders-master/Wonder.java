import java.util.TreeMap;

public class Wonder {
	private String material, name, bonus;
	private int currentLevel;
	private String[]one,two,three;
	private TreeMap<String, Integer> upgradeRequirements;
	public Wonder(int lvl, String mat, String named,String[]level1,String[]level2,String[]level3)
	{
		setCurrentLevel(lvl);
		setMaterial(mat);
		setName(named);
		setLVLOne(level1);
		setLVLTwo(level2);
		setLVLThree(level3);
	}
	public String getBonus() {
		return bonus;
	}
	public void setBonus(String bonus) {
		this.bonus = bonus;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMaterial() {
		return material;
	}
	public void setMaterial(String material) {
		this.material = material;
	}
	public TreeMap<String, Integer> getUpgradeRequirements() {
		return upgradeRequirements;
	}
	public void setUpgradeRequirements(TreeMap<String, Integer> upgradeRequirements) {
		this.upgradeRequirements = upgradeRequirements;
	}
	public int getCurrentLevel() {
		return currentLevel;
	}
	public void setCurrentLevel(int currentLevel) {
		this.currentLevel = currentLevel;
	}
	public void addCurrentLevel()
	{
		currentLevel++;
	}
	public boolean upgradeWonder()
	{
		addCurrentLevel();
		if(getCurrentLevel() == 2)
			return true;
		return false;
	}
	public void setLVLOne(String[]a) {
		one = a;
	}
     public void setLVLTwo(String[]a) {
		two = a;
	}
     public void setLVLThree(String[]a) {
 		three = a;
 	}
     public String[] getLVLOne() {
    	 return one;
     }
     public String[] getLVLTwo(){
    	return two;
     }
     public String[] getLVLThree(){
    	 return three;
     }


}
