import java.util.ArrayList;
import java.util.TreeMap;
import java.util.TreeSet;

public class Player {
	private TreeMap<String, Integer> materials;
	private ArrayList<Card> chooseHand;
	private TreeMap<String, ArrayList<Card>> hand;
	private int coins, losses;
	private String name;
	private int[] wins;
	private ArrayList<String> freeBuilds;
	private Wonder wonder;
	public Player(String nam)
	{
		coins = 3;
		freeBuilds = new ArrayList<String>();
		chooseHand = new ArrayList<Card>();
		hand = new TreeMap<>();
		hand.put("Resource", new ArrayList<Card>());
		hand.put("Civilian", new ArrayList<Card>());
		hand.put("Commerce/Trade", new ArrayList<Card>());
		hand.put("Guild", new ArrayList<Card>());
		hand.put("Military", new ArrayList<Card>());
		hand.put("Science", new ArrayList<Card>());
		materials = new TreeMap<>();
		materials.put("Stone", 0);
		materials.put("Timber", 0);
		materials.put("Clay", 0);
		materials.put("Ore", 0);
		materials.put("Loom", 0);
		materials.put("Papyrus", 0);
		materials.put("Glass", 0);
		losses = 0;
		wins = new int[3];
		setName(nam);
	}
	public void setName(String nam)
	{
		name = nam;
	}
	public int getWinNum()
	{
		int total = 0;
		for (int posi = 0; posi < wins.length; posi++)
		{
			if (posi == 0)
				total += wins[posi];
			else if (posi == 1)
				total += wins[posi] * 3;
			else if (posi == 2)
				total += wins[posi] * 5;
		}
		return total;
	}
	public TreeMap<String, Integer> getMaterials() {
		return materials;
	}
	public void setMaterials(TreeMap<String, Integer> materials) {
		this.materials = materials;
	}
	public ArrayList<Card> getChooseHand() {
		return chooseHand;
	}
	public void setChooseHand(ArrayList<Card> chooseHand) {
		this.chooseHand = chooseHand;
	}
	public TreeMap<String, ArrayList<Card>> getHand() {
		return hand;
	}
	public void setHand(TreeMap<String, ArrayList<Card>> hand) {
		this.hand = hand;
	}
	public int[] getWins() {
		return wins;
	}
	public int getCoins() {
		return coins;
	}
	public void setCoins(int coins) {
		this.coins = coins;
	}
	public int getLosses() {
		return losses;
	}
	public ArrayList<String> getFreeBuilds() {
		return freeBuilds;
	}
	public void setFreeBuilds(ArrayList<String> freeBuilds) {
		this.freeBuilds = freeBuilds;
	}
	public Wonder getWonder() {
		return wonder;
	}
	public void setWonder(Wonder wonder) {
		this.wonder = wonder;
		setWonderMat();
	}
	public void setWonderMat() {
		materials.put(getWonder().getMaterial(), (materials.get(getWonder().getMaterial()) + 1));
	}
	public void addToHand(Card c)
	{
		ArrayList<Card> temp = hand.get(c.getType());
		temp.add(c);
		hand.put(c.getType(), temp);
	}
	public void buildWonder(Card c)
	{
		wonder.upgradeWonder();
	}
	
	public ArrayList<Integer> calcScore(Player[] allPlayers, int current)
	{
		ArrayList<Integer> toReturn = new ArrayList<>();
		int score = 0, win = 0;;
		score -= losses;
		win += wins[0];
		win += wins[1]*3;
		win += wins[2]*5;
		score += win;
		score += coins/3;
		toReturn.add(-1 * losses);
		toReturn.add(win);
		toReturn.add(coins/3);
		int lvl = getWonder().getCurrentLevel();
		if(lvl == 0)
		{
			score += 0;
			toReturn.add(0);
		}	
		else if(lvl == 1)
		{
			score += 3;
			toReturn.add(3);
		}	
		else if(getWonder().getName().equals("Gizah"))
		{
			if(lvl == 2)
			{
				score += 8;
				toReturn.add(8);
			}
			else if(lvl == 3)
			{
				score += 15;
				toReturn.add(15);
			}
		}
		else if(lvl == 3)
		{
			score += 10;
			toReturn.add(10);
		}
		int civilian = 0;
		ArrayList<Card> temp = hand.get("Civilian");
		for(int i = 0; i < temp.size(); i++)
		{
			score += ((CivilianCard)temp.get(i)).getVPWorth();
			civilian += ((CivilianCard)temp.get(i)).getVPWorth();
		}
		toReturn.add(civilian);
		int sciences = 0;
		int[] science = new int[3];
		temp = hand.get("Science");
		for(int i = 0; i < temp.size(); i++)
		{
			if(((ScienceCard)temp.get(i)).getTypes().equals("math"))
				science[0]++;
			else if(((ScienceCard)temp.get(i)).getTypes().equals("literature"))
				science[1]++;
			else if(((ScienceCard)temp.get(i)).getTypes().equals("engineering"))
				science[2]++;
		}
		int smallest = Integer.MAX_VALUE;
		int largest = Integer.MIN_VALUE;
		int pos = 0;
		for(int i = 0; i < science.length; i++)
		{
			if(science[i] < smallest)
				smallest = science[i];
			if(science[i] > largest)
			{
				pos = i;
				largest = science[i];
			}
		}
		boolean isScientists = false, isBabylon = false;;
		ArrayList<Card> guild = hand.get("Guild");
		for(int i = 0; i < guild.size(); i++)
		{
			if(guild.get(i).getName().equals("ScientistsGuild"))
				isScientists = true;
		}
		if(getWonder().getName().equals("Babylon"))
			isBabylon = true;
		if(isScientists)
			science[pos]++;
		if(isBabylon)
			science[pos]++;
		for(int i = 0; i < science.length; i++)
		{
			score += science[i] * science[i];
			sciences += science[i] * science[i];
		}
		score += smallest*7;
		sciences += smallest*7;
		toReturn.add(sciences);
		int commerce = 0;
		temp = hand.get("Commerce/Trade");
		ArrayList<Card> temp2 = new ArrayList<Card>();
		for(int i = 0; i < temp.size(); i++)
		{
			if(((CommercialCard) temp.get(i)).getAge() == 3)
				temp2.add(temp.get(i));
		}
		for(int i = 0; i < temp2.size(); i++)
		{
			if(temp2.get(i).getName().equals("Haven"))
			{
				ArrayList<Card> temp3 = hand.get("Resource");
				for(int j = 0; j < temp3.size(); j++)
				{
					if(temp3.get(i).getName().equals("Press") || temp3.get(i).getName().equals("Loom") || temp3.get(i).getName().equals("Press") || temp3.get(i).getName().equals("Glassworks"))
						temp3.remove(i);
				}
				score += temp3.size();
				commerce += temp3.size();
			}
			else if(temp2.get(i).getName().equals("Lighthouse"))
			{
				score += hand.get("Commercial/Trade").size();
				commerce += hand.get("Commercial/Trade").size();
			}
			else if(temp2.get(i).getName().equals("Arena"))
			{
				score += getWonder().getCurrentLevel();
				commerce += getWonder().getCurrentLevel();
			}
		}
		toReturn.add(commerce);
		int guilds = 0;
		for(int i = 0; i < guild.size(); i++)
		{
			int add = 0;
			if(guild.get(i).getName().equals("BuildersGuild"))
			{
				for(int j = 0; j < allPlayers.length; j++)
				{
					add += allPlayers[j].getWonder().getCurrentLevel();
				}
			}
			else if(guild.get(i).getName().equals("StrategistsGuild"))
			{
				for(int j = 0; j < allPlayers.length; j++)
				{
					add += allPlayers[j].getLosses();
				}
				add -= getLosses();
			}
			else if(guild.get(i).getName().equals("ShipownersGuild"))
			{
				add += hand.get("Resource").size() + hand.get("Civilian").size();
			}
			else
			{
				ArrayList<Card> temp4;
				for(int j = 0; j < allPlayers.length; j++)
				{
					temp4 = allPlayers[j].getHand().get(((GuildCard)guild.get(i)).getTypeEarned());
					if(((GuildCard)guild.get(i)).getTypeEarned().equals("Resource"))
					{
						ArrayList<Card> grey = new ArrayList<Card>();
						for(int k = temp4.size(); k > -1; k--)
						{
							if(temp4.get(i).getName().equals("Loom") || temp4.get(i).getName().equals("Press") || temp4.get(i).getName().equals("Glassworks"))
								grey.add(temp4.remove(k));
						}
						if(((GuildCard)guild.get(i)).getAmt() == 2 && i != current)
						{
							add += grey.size() * 2;
						}
						else if(i != current)
						{
							add += temp4.size();
						}
					}
					/*
					else
					{
						if(i != current)
							add += temp4.size();
					}*/
				}
			}
			score += add;
			guilds += add;
		}
		toReturn.add(guilds);
		toReturn.add(score);
		return toReturn;
	}
	public void updateMats()
	{
		ArrayList<Card> temp = hand.get("Resource");
		if (temp.isEmpty())
			return;
		for(int i = temp.size() - 1; i > -1; i--)
		{
			if(!((MaterialCard)temp.get(i)).isChoice())
			{
				String[] arr = ((MaterialCard)temp.get(i)).getMaterial();
				for(int j = 0; j < arr.length; j++)
				{
					materials.put(arr[j], materials.get(arr[j])+1);
				}
			}
		}
	}
	public void updateFree(Card c)
	{
		if(!(c.getUpgrades().equals(null)))
		{
			String[] up = c.getUpgrades();
			for(int i = 0; i < up.length; i++)
			{
				freeBuilds.add(up[i]);
			}
		}
	}
	public void addToLosses(int l)
	{
		losses += l;
	}
	public void addCoins(int c)
	{
		coins += c;
	}
	public void addToWins(int w, int age)
	{
		wins[age-1] += w;
	}
}
